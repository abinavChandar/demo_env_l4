from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    center_col = dsl_paint_col(dsl_zeros_like(grid, 0), dsl_shape(grid)[1] // 2, 0)
    for r, c in dsl_iter_coords(grid):
        if dsl_get_cell(center_col, c) == 3:
            center_col = dsl_paint_cell(center_col, c, 6)
        elif dsl_get_cell(center_col, c) == 5:
            center_col = dsl_paint_cell(center_col, c, 5)
        elif dsl_get_cell(center_col, c) == 8:
            center_col = dsl_paint_cell(center_col, c, 8)
        elif dsl_get_cell(center_col, c) == 2:
            center_col = dsl_paint_cell(center_col, c, 2)
        elif dsl_get_cell(center_col, c) == 4:
            center_col = dsl_paint_cell(center_col, c, 4)
        elif dsl_get_cell(center_col, c) == 6:
            center_col = dsl_paint_cell(center_col, c, 6)
        elif dsl_get_cell(center_col, c) == 3:
            center_col = dsl_paint_cell(center_col, c, 3)
        elif dsl_get_cell(center_col, c) == 0:
            center_col = dsl_paint_cell(center_col, c, 0)
    grid = dsl_paint_col(grid, 0, dsl_zeros_like(grid, 0))
    grid = dsl_paint_col(grid, dsl_shape(grid)[1] - 1, dsl_zeros_like(grid, 0))
    grid = dsl_paint_row(grid, 0, dsl_zeros_like(grid, 0))
    grid = dsl_paint_row(grid, dsl_shape(grid)[0] - 1, dsl_zeros_like(grid, 0))
    output = dsl_zeros_like(grid, 0)
    for r, c in dsl_iter_coords(grid):
        if dsl_in_bounds(grid, r, c):
            output = dsl_paint_cell(output, c, dsl_get_cell(grid, r))
    for r, c in dsl_iter_coords(grid):
        if dsl_in_bounds(grid, r, c):
            if c < dsl_shape(grid)[1] // 2:
                output = dsl_paint_cell(output, dsl_shape(grid)[1] // 2 + c, dsl_get_cell(grid, r))
            else:
                output = dsl_paint_cell(output, dsl_shape(grid)[1] // 2 - c, dsl_get_cell(grid, r))
    grid = dsl_paint_col(grid, 0, dsl_zeros_like(grid, 0))
    grid = dsl_paint_col(grid, dsl_shape(grid)[1] - 1, dsl_zeros_like(grid, 0))
    grid = dsl_paint_row(grid, 0, dsl_zeros_like(grid, 0))
    grid = dsl_paint_row(grid, dsl_shape(grid)[0] - 1, dsl_zeros_like(grid, 0))
    output = dsl_paint_col(output, 0, dsl_zeros_like(output, 0))
    output = dsl_paint_col(output, dsl_shape(output)[1] - 1, dsl_zeros_like(output, 0))
    output = dsl_paint_row(output, 0, dsl_zeros_like(output, 0))
    output = dsl_paint_row(output, dsl_shape(output)[0] - 1, dsl_zeros_like(output, 0))
    for r, c in dsl_iter_coords(grid):
        if dsl_in_bounds(grid, r, c):
            if c < dsl_shape(grid)[1] // 2:
                output = dsl_paint_cell(output, dsl_shape(grid)[1] // 2 + c, dsl_get_cell(grid, r))
            else:
                output = dsl_paint_cell(output, dsl_shape(grid)[1] // 2 - c, dsl_get_cell(grid, r))
    return output