from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    def new_square(r0: int, c0: int, h: int, w: int) -> List[List[int]]:
        return dsl_fill_rect(dsl_zeros_like(grid, 4), r0, c0, h, w, 4)

    def remove_outside_4s(G: List[List[int]]) -> List[List[int]]:
        return dsl_replace_color(G, 4, 0)

    def is_new_square_fully_contained(G: List[List[int]], new_square: List[List[int]]) -> bool:
        return dsl_bbox_of_mask(dsl_mask_eq(G, 4)) is None or dsl_bbox_of_mask(dsl_mask_eq(new_square, 4)) is None

    while True:
        outermost_4_bbox = dsl_bbox_of_mask(dsl_mask_eq(grid, 4))
        if outermost_4_bbox is None:
            return grid
        r0, c0, r1, c1 = outermost_4_bbox
        new_square_size = max(r1 - r0, c1 - c0)
        new_square_r0, new_square_c0 = r0 - new_square_size // 2, c0 - new_square_size // 2
        new_square = new_square(new_square_r0, new_square_c0, new_square_size, new_square_size)
        new_square_bbox = dsl_bbox_of_mask(dsl_mask_eq(new_square, 4))
        if new_square_bbox is None:
            return grid
        new_square_r0, new_square_c0, new_square_r1, new_square_c1 = new_square_bbox
        if new_square_r0 < 0 or new_square_c0 < 0 or new_square_r1 >= dsl_shape(grid)[0] or new_square_c1 >= dsl_shape(grid)[1]:
            grid = remove_outside_4s(grid)
            continue
        if is_new_square_fully_contained(grid, new_square):
            break
        grid = remove_outside_4s(grid)
        grid = dsl_paste_masked(grid, new_square, new_square_r0, new_square_c0, dsl_mask_eq(new_square, 4))