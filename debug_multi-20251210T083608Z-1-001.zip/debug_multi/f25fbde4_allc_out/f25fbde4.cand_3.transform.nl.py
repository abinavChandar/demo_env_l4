from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    max_val = 4
    max_bbox = dsl_bbox_of_mask(dsl_mask_eq(grid, max_val))
    if max_bbox is None:
        return grid
    max_r0, max_c0, max_h, max_w = max_bbox
    max_subgrid = dsl_crop(grid, max_r0, max_c0, max_h, max_w)
    rotated_subgrid = dsl_rot90(max_subgrid, 1)
    center_r = len(grid) // 2
    center_c = len(grid[0]) // 2
    output = dsl_zeros_like(grid, 4)
    dsl_paste(output, rotated_subgrid, center_r - max_h // 2, center_c - max_w // 2)
    r, c = center_r - 1, center_c - 1
    direction = 0
    for _ in range((len(grid) + len(grid[0]) - 2) // 2):
        output = dsl_paint_cell(output, r, c, 4)
        if direction == 0 and c < center_c - 1:
            c += 1
        elif direction == 0 and c == center_c - 1 and r < center_r - 1:
            r += 1
            direction = 1
        elif direction == 1 and r < center_r - 1:
            r += 1
        elif direction == 1 and r == center_r - 1 and c < center_c + 1:
            c += 1
            direction = 2
        elif direction == 2 and c < center_c + 1:
            c += 1
        elif direction == 2 and c == center_c + 1 and r > center_r - 1:
            r -= 1
            direction = 3
        elif direction == 3 and r > center_r - 1:
            r -= 1
        elif direction == 3 and r == center_r - 1 and c > center_c - 1:
            c -= 1
            direction = 0
    return output