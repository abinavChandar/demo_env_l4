from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    max_val = 4
    max_bbox = dsl_bbox_of_mask(dsl_mask_eq(grid, max_val))
    if max_bbox is None:
        return dsl_full(dsl_shape(grid)[0], dsl_shape(grid)[1], 0)
    max_subgrid = dsl_crop(grid, max_bbox[0], max_bbox[1], max_bbox[2] - max_bbox[0], max_bbox[3] - max_bbox[1])
    rotated_subgrid = dsl_rot90(max_subgrid, 1)
    center_r = dsl_shape(grid)[0] // 2
    center_c = dsl_shape(grid)[1] // 2
    output = dsl_zeros_like(grid, 0)
    output = dsl_paste(output, rotated_subgrid, center_r - (dsl_shape(rotated_subgrid)[0] // 2), center_c - (dsl_shape(rotated_subgrid)[1] // 2))
    return output