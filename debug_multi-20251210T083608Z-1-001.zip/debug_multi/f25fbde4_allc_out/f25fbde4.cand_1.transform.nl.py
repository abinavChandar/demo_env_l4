from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    center = (dsl_shape(grid)[0] // 2, dsl_shape(grid)[1] // 2)
    target_cells = [r for r, row in enumerate(grid) for c, cell in enumerate(row) if cell == 4]
    for r, c in target_cells:
        distance = dsl_distance((r, c), center)
        if distance <= 2:
            continue
        elif distance == 3:
            if r < center[0]:
                grid = dsl_paint_row(grid, r, dsl_get_cell(grid, center[0], c))
            elif r > center[0]:
                grid = dsl_paint_row(grid, r, dsl_get_cell(grid, center[0], c))
            elif c < center[1]:
                grid = dsl_paint_col(grid, c, dsl_get_cell(grid, r, center[1]))
            elif c > center[1]:
                grid = dsl_paint_col(grid, c, dsl_get_cell(grid, r, center[1]))
        else:
            grid = dsl_paint_row(grid, r, dsl_get_cell(grid, center[0], center[1]))
            grid = dsl_paint_col(grid, c, dsl_get_cell(grid, r, center[1]))
    return grid

def dsl_distance(p1: Tuple[int, int], p2: Tuple[int, int]) -> int:
    return dsl_clamp(abs(p1[0] - p2[0]) + abs(p1[1] - p2[1]))