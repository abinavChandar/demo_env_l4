from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    outer_square = dsl_crop(grid, 2, 2, 5, 5)
    inner_square = dsl_crop(outer_square, 1, 1, 3, 3)
    max_val = max(max(row) for row in inner_square)
    max_coords = next((r, c) for r, row in enumerate(inner_square) for c, val in enumerate(row) if val == max_val)
    target_square = dsl_rot90(dsl_crop(inner_square, max_coords[0], max_coords[1], 3, 3))
    center_coords = (2, 2)
    target_square = dsl_paint_row(target_square, center_coords[0], 4)
    target_square = dsl_paint_col(target_square, center_coords[1], 4)
    outer_square = dsl_zeros_like(outer_square)
    outer_square = dsl_paint_row(outer_square, center_coords[0], 4)
    outer_square = dsl_paint_col(outer_square, center_coords[1], 4)
    outer_square = dsl_paste(outer_square, target_square, center_coords[0], center_coords[1])
    return outer_square