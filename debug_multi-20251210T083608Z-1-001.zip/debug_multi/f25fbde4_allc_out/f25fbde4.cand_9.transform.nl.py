from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    def process_subgrid(G: List[List[int]]) -> List[List[int]]:
        R = dsl_rot90(dsl_crop(G, 0, 0, 3, 3), 1)
        T = dsl_paste(dsl_zeros_like(G, 4), R, 0, 0)
        return dsl_fill_rect(T, 0, 0, dsl_shape(G)[0], dsl_shape(G)[1], 4)

    def process_grid(G: List[List[int]]) -> List[List[int]]:
        if dsl_shape(G)[0] <= 3:
            return G
        return dsl_transpose(dsl_paint_row(dsl_paint_col(process_subgrid(dsl_clone(G)), 0, 4), 0, 4))

    return process_grid(grid)