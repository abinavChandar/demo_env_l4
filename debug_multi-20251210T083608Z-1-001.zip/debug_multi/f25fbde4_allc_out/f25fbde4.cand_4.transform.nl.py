from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    max_val = 4
    max_bbox = dsl_bbox_of_mask(dsl_mask_eq(grid, max_val))
    if max_bbox is None:
        return dsl_full(dsl_shape(grid)[0], dsl_shape(grid)[1], max_val)
    max_subgrid = dsl_crop(grid, max_bbox[0], max_bbox[1], max_bbox[2], max_bbox[3])
    rotated_subgrid = dsl_rot90(max_subgrid, 1)
    center_bbox = dsl_bbox_of_mask(dsl_mask_eq(dsl_zeros_like(grid, 0), 0))
    center_subgrid = dsl_crop(grid, center_bbox[0], center_bbox[1], center_bbox[2], center_bbox[3])
    center_subgrid = dsl_paint_row(center_subgrid, center_bbox[0] + center_bbox[2] // 2, 0)
    center_subgrid = dsl_paint_col(center_subgrid, center_bbox[1] + center_bbox[3] // 2, 0)
    output_grid = dsl_paste_masked(grid, rotated_subgrid, max_bbox[0] + max_bbox[2] // 2, max_bbox[1] + max_bbox[3] // 2, dsl_zeros_like(grid, 0))
    output_grid = dsl_paint_row(output_grid, 0, max_val)
    output_grid = dsl_paint_col(output_grid, 0, max_val)
    if dsl_shape(grid)[0] % 2 == 1:
        output_grid = dsl_set_cell(output_grid, center_bbox[0] + center_bbox[2] // 2, center_bbox[1] + center_bbox[3] // 2, 0)
    if dsl_shape(grid)[1] % 2 == 1:
        output_grid = dsl_set_cell(output_grid, center_bbox[0] + center_bbox[2] // 2, center_bbox[1] + center_bbox[3] // 2, 0)
    return output_grid