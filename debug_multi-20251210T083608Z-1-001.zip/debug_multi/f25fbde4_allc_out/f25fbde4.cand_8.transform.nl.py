from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    top_left_3x3 = dsl_crop(grid, 0, 0, 3, 3)
    rotated_3x3 = dsl_rot90(top_left_3x3, 1)
    center_r = dsl_shape(grid)[0] // 2 - 1
    center_c = dsl_shape(grid)[1] // 2 - 1
    output = dsl_zeros_like(grid, 4)
    dsl_paint_row(output, center_r - 1, 0)
    dsl_paint_col(output, center_c - 1, 0)
    dsl_paste(output, rotated_3x3, center_r - 1, center_c - 1)
    return output