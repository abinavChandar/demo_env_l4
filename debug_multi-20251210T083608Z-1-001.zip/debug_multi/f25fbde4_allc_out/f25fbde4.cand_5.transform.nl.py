from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    mask = dsl_mask_eq(grid, 0)
    sub_grid = dsl_crop(grid, *dsl_bbox_of_mask(mask)[:-1])
    sub_grid = dsl_rot90(sub_grid, 1)
    center = dsl_shape(dsl_zeros_like(grid))[::-1] // 2
    grid = dsl_paste_masked(grid, sub_grid, *center, dsl_component_mask(grid, *center))
    grid = dsl_paint_row(grid, *center, 0)
    grid = dsl_paint_col(grid, *center, 0)
    return grid