from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    max_val = 4
    max_bbox = dsl_bbox_of_mask(dsl_mask_eq(grid, max_val))
    if max_bbox is None:
        return grid
    max_subgrid = dsl_crop(grid, max_bbox[0], max_bbox[1], 4, 4)
    new_subgrid = dsl_rot90(max_subgrid, 1)
    center_r = dsl_shape(grid)[0] // 2
    center_c = dsl_shape(grid)[1] // 2
    output = dsl_zeros_like(grid, max_val)
    dsl_paint_row(output, center_r, max_val)
    dsl_paint_col(output, center_c, max_val)
    dsl_paint_row(output, center_r - 1, max_val)
    dsl_paint_col(output, center_c - 1, max_val)
    dsl_paint_row(output, center_r - 2, max_val)
    dsl_paint_col(output, center_c - 2, max_val)
    dsl_paint_row(output, center_r - 3, max_val)
    dsl_paint_col(output, center_c - 3, max_val)
    dsl_paste_masked(output, new_subgrid, center_r - 2, center_c - 2, dsl_mask_eq(new_subgrid, max_val))
    return output