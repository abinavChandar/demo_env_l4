from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    unique_num = dsl_get_cell(grid, *dsl_iter_coords(grid)[0])
    grid = dsl_replace_color(grid, 0, unique_num)
    grid = dsl_flip_v(dsl_flip_h(grid))
    mid_row = dsl_iter_coords(grid)[len(grid) // 2]
    grid = dsl_paint_row(grid, mid_row[0], unique_num)
    return grid