from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    unique_value = dsl_get_cell(grid, *dsl_iter_coords(grid)[0])
    grid = dsl_replace_color(grid, unique_value, 1)
    grid = dsl_paint_row(grid, 0, 1)
    grid = dsl_paint_col(grid, 0, 1)
    return grid