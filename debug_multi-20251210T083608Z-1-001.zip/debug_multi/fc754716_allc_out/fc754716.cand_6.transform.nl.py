from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    unique = dsl_get_cell(grid, *dsl_iter_coords(dsl_mask_eq(grid, dsl_get_cell(grid, *dsl_iter_coords(grid)))))

    grid = dsl_replace_color(grid, 0, unique)

    grid = dsl_flip_v(dsl_flip_h(grid))

    mid_row = dsl_zeros_like(grid, 0)
    mid_row = dsl_set_cell(mid_row, dsl_shape(grid)[0] // 2, 0, 0)

    grid = dsl_copy_row(grid, dsl_shape(grid)[0] // 2, dsl_shape(grid)[0] // 2)
    grid = dsl_paint_row(grid, dsl_shape(grid)[0] // 2, 0)

    return grid