from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    unique = dsl_get_cell(grid, dsl_bbox_of_mask(dsl_mask_eq(grid, 0))[0], dsl_bbox_of_mask(dsl_mask_eq(grid, 0))[1])[0]
    grid = dsl_replace_color(grid, 0, unique)
    return dsl_replace_color(dsl_zeros_like(grid, unique), unique)