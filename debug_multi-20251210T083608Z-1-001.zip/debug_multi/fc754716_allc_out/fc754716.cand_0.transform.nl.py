from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    unique_value = dsl_remap_colors(dsl_mask_eq(grid, dsl_get_cell(grid, *dsl_iter_coords(grid)[0])), {0: 1, 1: 2})[0][0]
    grid = dsl_replace_color(dsl_replace_color(dsl_full(dsl_shape(grid)[0], dsl_shape(grid)[1], 1), unique_value, 0), 0, 1)
    grid = dsl_paint_row(grid, dsl_iter_coords(grid)[0][0], 1)
    grid = dsl_paint_col(grid, dsl_iter_coords(grid)[0][1], 1)
    return grid