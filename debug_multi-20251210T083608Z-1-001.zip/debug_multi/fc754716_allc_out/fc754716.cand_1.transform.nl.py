from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    unique_num = dsl_get_cell(grid, *dsl_iter_coords(grid)[0])
    grid = dsl_replace_color(grid, 0, unique_num)
    grid = dsl_flip_v(dsl_flip_h(grid))
    if dsl_shape(grid)[0] % 2 == 1:
        grid = dsl_copy_row(grid, dsl_shape(grid)[0] // 2, 0)
    if dsl_shape(grid)[1] % 2 == 1:
        grid = dsl_copy_col(grid, dsl_shape(grid)[1] // 2, 0)
    return grid