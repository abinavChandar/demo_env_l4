from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    unique_num = dsl_get_cell(grid, *dsl_bbox_of_mask(dsl_mask_eq(grid, 0))[0])
    grid = dsl_replace_color(grid, 0, unique_num)
    grid = dsl_full(dsl_shape(grid)[0], dsl_shape(grid)[1], unique_num)
    grid = dsl_paint_row(grid, 0, 0)
    grid = dsl_paint_row(grid, dsl_shape(grid)[0] - 1, 0)
    grid = dsl_paint_row(grid, dsl_shape(grid)[0] // 2, 0)
    return grid