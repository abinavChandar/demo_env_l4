from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    unique_val = dsl_remap_colors(grid, {v: 1 for v in set(v for row in grid for v in row) if v != 0})[0][0]
    grid = dsl_replace_color(grid, unique_val, 1)
    if dsl_get_cell(grid, dsl_shape(grid)[0] // 2, dsl_shape(grid)[1] // 2) == unique_val:
        grid = dsl_flip_h(dsl_flip_v(grid))
    return dsl_full(dsl_shape(grid)[0], dsl_shape(grid)[1], 1)