from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    unique_value = dsl_get_cell(grid, *dsl_bbox_of_mask(dsl_mask_eq(grid, dsl_get_cell(grid, *dsl_iter_coords(grid)[0])))[0])
    return dsl_replace_color(grid, 0, unique_value)