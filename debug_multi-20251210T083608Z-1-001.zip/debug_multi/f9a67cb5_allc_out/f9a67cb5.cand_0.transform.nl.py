from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    mask = dsl_mask_eq(grid, 8)
    for r, c in dsl_iter_coords(grid):
        if dsl_get_cell(mask, r, c):
            size = dsl_shape(dsl_component_mask(grid, r, c))[0]
            square = dsl_zeros_like(grid, 2)
            dsl_paint_cell(square, r - size // 2, c - size // 2, 2)
            dsl_paint_cell(square, r - size // 2, c - size // 2 + 1, 2)
            dsl_paint_cell(square, r - size // 2 + 1, c - size // 2, 2)
            dsl_paint_cell(square, r - size // 2 + 1, c - size // 2 + 1, 2)
            dsl_paint_cell(square, r - size // 2, c + size // 2, 2)
            dsl_paint_cell(square, r - size // 2, c + size // 2 + 1, 2)
            dsl_paint_cell(square, r - size // 2 + 1, c + size // 2, 2)
            dsl_paint_cell(square, r - size // 2 + 1, c + size // 2 + 1, 2)
            dsl_paint_cell(square, r + size // 2, c - size // 2, 2)
            dsl_paint_cell(square, r + size // 2, c - size // 2 + 1, 2)
            dsl_paint_cell(square, r + size // 2 + 1, c - size // 2, 2)
            dsl_paint_cell(square, r + size // 2 + 1, c - size // 2 + 1, 2)
            dsl_paint_cell(square, r + size // 2, c + size // 2, 2)
            dsl_paint_cell(square, r + size // 2, c + size // 2 + 1, 2)
            dsl_paint_cell(square, r + size // 2 + 1, c + size // 2, 2)
            dsl_paint_cell(square, r + size // 2 + 1, c + size // 2 + 1, 2)
            dsl_paint_row(square, r - size // 2, 2)
            dsl_paint_row(square, r + size // 2 + 1, 2)
            dsl_paint_col(square, c - size // 2, 2)
            dsl_paint_col(square, c + size // 2 + 1, 2)
            dsl_paint_cell(square, r - size // 2, c - size // 2, 8)
            grid = dsl_paste_masked(grid, square, r - size // 2, c - size // 2, mask)
    return grid