from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    top_left_3x3 = dsl_crop(grid, 0, 0, 3, 3)
    grid = dsl_fill_rect(dsl_zeros_like(grid), 0, 0, 3, 3, 0)
    top_left_3x3_output = dsl_crop(grid, 0, 0, 3, 3)
    grid = dsl_paste_masked(grid, grid, 0, 0, dsl_mask_eq(grid, 0))
    grid = dsl_replace_color(grid, 0, dsl_get_cell(top_left_3x3, 0, 0))
    grid = dsl_replace_color(grid, 0, dsl_get_cell(top_left_3x3, 1, 0))
    grid = dsl_replace_color(grid, 0, dsl_get_cell(top_left_3x3, 2, 0))
    grid = dsl_replace_color(grid, 0, dsl_get_cell(top_left_3x3, 0, 1))
    grid = dsl_replace_color(grid, 0, dsl_get_cell(top_left_3x3, 1, 1))
    grid = dsl_replace_color(grid, 0, dsl_get_cell(top_left_3x3, 2, 1))
    grid = dsl_replace_color(grid, 0, dsl_get_cell(top_left_3x3, 0, 2))
    grid = dsl_replace_color(grid, 0, dsl_get_cell(top_left_3x3, 1, 2))
    grid = dsl_replace_color(grid, 0, dsl_get_cell(top_left_3x3, 2, 2))
    grid = dsl_paste_masked(grid, top_left_3x3, 0, 0, dsl_mask_eq(top_left_3x3, 0))
    return grid