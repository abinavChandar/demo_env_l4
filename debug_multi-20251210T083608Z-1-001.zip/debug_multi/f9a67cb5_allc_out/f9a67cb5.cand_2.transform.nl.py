from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    grid = dsl_clone(grid)
    while True:
        new_grid = dsl_clone(grid)
        for r, c in dsl_iter_coords(grid):
            if dsl_get_cell(grid, r, c) != 0:
                closest = None
                for dr, dc in dsl_neighbors4(r, c):
                    if dsl_in_bounds(grid, dr, dc) and dsl_get_cell(grid, dr, dc) != 0:
                        if closest is None or dsl_get_cell(grid, dr, dc) < dsl_get_cell(grid, r, c):
                            closest = (dr, dc)
                if closest is not None:
                    dsl_set_cell(new_grid, r, c, dsl_get_cell(grid, *closest))
                else:
                    dsl_set_cell(new_grid, r, c, 2)
        if grid == new_grid:
            break
        grid = new_grid
    return grid