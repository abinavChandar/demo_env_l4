from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    mask = dsl_mask_eq(grid, 8)
    grid = dsl_replace_color(grid, 8, 2)
    square_size = dsl_shape(dsl_bbox_of_mask(mask))[0]
    for r, c in dsl_iter_coords(grid):
        if dsl_get_cell(mask, r, c):
            for dr, dc in dsl_neighbors4(r, c):
                if dsl_in_bounds(grid, dr, dc):
                    grid = dsl_paint_cell(grid, dr, dc, 2)
                    if dsl_in_bounds(grid, dr + dr, dc + dc):
                        grid = dsl_paint_cell(grid, dr + dr, dc + dc, 2)
                    if dsl_in_bounds(grid, dr - dr, dc - dc):
                        grid = dsl_paint_cell(grid, dr - dr, dc - dc, 2)
                    if dsl_in_bounds(grid, dr + dr, dc - dc):
                        grid = dsl_paint_cell(grid, dr + dr, dc - dc, 2)
                    if dsl_in_bounds(grid, dr - dr, dc + dc):
                        grid = dsl_paint_cell(grid, dr - dr, dc + dc, 2)
    for r, c in dsl_iter_coords(grid):
        if dsl_get_cell(mask, r, c):
            for dr, dc in dsl_neighbors4(r, c):
                if dsl_in_bounds(grid, dr, dc):
                    if dsl_in_bounds(grid, dr + dr, dc + dc):
                        grid = dsl_paint_cell(grid, dr + dr, dc + dc, 2)
                    if dsl_in_bounds(grid, dr - dr, dc - dc):
                        grid = dsl_paint_cell(grid, dr - dr, dc - dc, 2)
                    if dsl_in_bounds(grid, dr + dr, dc - dc):
                        grid = dsl_paint_cell(grid, dr + dr, dc - dc, 2)
                    if dsl_in_bounds(grid, dr - dr, dc + dc):
                        grid = dsl_paint_cell(grid, dr - dr, dc + dc, 2)
    return grid