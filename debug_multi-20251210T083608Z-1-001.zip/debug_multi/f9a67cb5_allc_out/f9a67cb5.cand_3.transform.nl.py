from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    top_row = dsl_mask_eq(grid, 2)
    bottom_row = dsl_mask_eq(grid, 2)
    if dsl_shape(grid)[0] == 6:
        middle_row = dsl_full(1, dsl_shape(grid)[1], 2)
    else:
        middle_row = dsl_zeros_like(grid)
    output = dsl_zeros_like(grid)
    dsl_paint_row(output, 0, dsl_apply_mask_color(dsl_full(1, dsl_shape(grid)[1], 2), top_row, 2))
    dsl_paint_row(output, dsl_shape(grid)[0] - 1, dsl_apply_mask_color(dsl_full(1, dsl_shape(grid)[1], 2), bottom_row, 0))
    for r in dsl_iter_coords(grid):
        if r[0] == dsl_shape(grid)[0] // 2:
            dsl_paint_row(output, r[0], middle_row)
        else:
            dsl_paint_row(output, r[0], dsl_remap_colors(dsl_clone(grid), {8: 8, 0: 0, 2: 2, -1: 2}))
    return output