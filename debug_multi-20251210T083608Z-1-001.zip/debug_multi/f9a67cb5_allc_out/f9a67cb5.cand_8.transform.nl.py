from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    mask = dsl_mask_eq(grid, 8)
    new_grid = dsl_clone(grid)
    for r, c in dsl_iter_coords(mask):
        if dsl_in_bounds(new_grid, r - 1, c):
            dsl_set_cell(new_grid, r - 1, c, 8)
        if dsl_in_bounds(new_grid, r + 1, c):
            dsl_set_cell(new_grid, r + 1, c, 8)
        dsl_paint_row(new_grid, r, 2)
        dsl_paint_col(new_grid, c, 2)
        dsl_paint_cell(new_grid, r, c, 2)
    return new_grid