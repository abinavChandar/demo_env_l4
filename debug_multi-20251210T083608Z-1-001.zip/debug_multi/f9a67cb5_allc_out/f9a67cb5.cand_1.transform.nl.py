from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    top_left = dsl_crop(grid, 0, 0, 3, 3)
    grid = dsl_fill_rect(grid, 0, 0, 3, 3, 0)
    grid = dsl_flood_fill(grid, 0, 0, 2)
    grid = dsl_flood_fill(grid, 0, 0, 2, mask=dsl_mask_eq(top_left, 8))
    grid = dsl_flood_fill(grid, 0, 0, 2, mask=dsl_mask_eq(top_left, 0) & dsl_mask_eq(dsl_neighbors4(0, 0), 2))
    return grid