from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    mask_2 = dsl_mask_eq(grid, 2)
    mask_8 = dsl_mask_eq(grid, 8)
    mask_8_in_2_row = dsl_paint_row(dsl_paint_row(mask_8, 0, 2), 0, 2)
    mask_8_not_in_2_row = dsl_paint_row(dsl_paint_row(mask_8, 0, 2), 0, 8)
    mask_2_row = dsl_mask_eq(dsl_paint_row(grid, 0, 2), 2)
    mask_2_row_not = dsl_mask_eq(dsl_paint_row(grid, 0, 2), 8)
    grid_2 = dsl_paint_row(dsl_paint_col(mask_8_in_2_row, 0, 2), 0, 2)
    grid_8 = dsl_paint_row(dsl_paint_col(mask_8_not_in_2_row, 0, 8), 0, 8)
    grid_2_row = dsl_paint_row(mask_2_row, 0, 2)
    grid_8_row = dsl_paint_row(mask_2_row_not, 0, 8)
    grid = dsl_paste(grid_2_row, grid_2, 0, 0)
    grid = dsl_paste(grid_8_row, grid_8, 0, 0)
    return grid