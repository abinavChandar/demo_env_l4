from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    dsl_paint_row(dsl_paint_col(dsl_paint_cell(grid, dsl_iter_coords(grid), 2, 8), dsl_iter_coords(grid), 1, 8), dsl_iter_coords(grid), 4, 8)
    dsl_paint_row(dsl_paint_col(dsl_paint_cell(grid, dsl_iter_coords(grid), 1, 0), dsl_iter_coords(grid), 0, 0), dsl_iter_coords(grid), 4, 0)
    dsl_paint_row(dsl_paint_col(dsl_paint_cell(grid, dsl_iter_coords(grid), 8, 8), dsl_iter_coords(grid), 0, 0), dsl_iter_coords(grid), 8, 0)
    return dsl_mask_eq(dsl_paint_row(dsl_paint_col(grid, dsl_iter_coords(grid), 0, 0), dsl_iter_coords(grid), 0, 0), 0)