from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    mask = dsl_mask_eq(grid, 2)
    circles = dsl_iter_coords(mask)
    intersection_counts = {}
    for r, c in circles:
        bbox = dsl_bbox_of_mask(dsl_component_mask(grid, r, c))
        r0, c0, h, w = bbox
        intersection_count = 0
        for dr, dc in dsl_neighbors4(r, c):
            if dsl_in_bounds(grid, dr, dc):
                if (dr == r0 or dr == r0 + h - 1 or
                    dc == c0 or dc == c0 + w - 1):
                    intersection_count += 1
                elif (dr == r0 + 1 and dc == c0 + 1 or
                      dr == r0 + h - 2 and dc == c0 + w - 2 or
                      dr == r0 + 1 and dc == c0 + w - 2 or
                      dr == r0 + h - 2 and dc == c0 + 1):
                    intersection_count += 0.5
        intersection_counts[(r, c)] = round(intersection_count)
    grid = dsl_remap_colors(grid, {2: intersection_counts})
    grid = dsl_iter_coords(grid)
    for r, c in grid:
        if dsl_get_cell(grid, r, c) != 0:
            row_count = sum(intersection_counts.get((r, cc), 0) for cc in dsl_iter_coords(grid) if cc[0] == c)
            col_count = sum(intersection_counts.get((rr, c), 0) for rr in dsl_iter_coords(grid) if rr[0] == r)
            grid = dsl_set_cell(grid, r, c, (row_count + col_count) % 2 + 8 * (row_count + col_count) // 2)
    grid = dsl_remap_colors(grid, {0: 0, 0.5: 4, 1: 1, 8: 8})
    return grid