from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    mask = dsl_mask_eq(grid, 2)
    grid = dsl_paint_row(grid, 0, 1)
    grid = dsl_paint_row(grid, len(grid) - 1, 1)
    grid = dsl_paint_col(grid, 0, 1)
    grid = dsl_paint_col(grid, len(grid[0]) - 1, 1)
    grid = dsl_paint_row(grid, len(grid) // 2, 2)
    grid = dsl_paint_col(grid, len(grid[0]) // 2, 2)
    grid = dsl_replace_color(grid, 1, 1)
    grid = dsl_replace_color(grid, 2, 2)
    grid = dsl_replace_color(grid, 4, 4)
    grid = dsl_replace_color(grid, 8, 4)
    grid = dsl_fill_rect(grid, 0, 0, len(grid), len(grid[0]), 0)
    grid = dsl_paint_masked(grid, mask, 0)
    return grid