from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    while True:
        new_grid = dsl_clone(grid)
        mask = dsl_mask_eq(grid, 2)
        grid = dsl_replace_color(grid, 2, 1)
        grid = dsl_paint_row(grid, 0, 0)
        for r, c in dsl_iter_coords(grid):
            if dsl_get_cell(grid, r, c) == 1:
                closest_8 = next((n for n in dsl_neighbors4(r, c) if dsl_get_cell(grid, n[0], n[1]) == 8), None)
                if closest_8:
                    grid = dsl_set_cell(grid, closest_8[0], closest_8[1], 8)
        mask = dsl_mask_eq(grid, 8)
        grid = dsl_replace_color(grid, 8, 4)
        grid = dsl_paint_row(grid, 0, 0)
        for r, c in dsl_iter_coords(grid):
            if dsl_get_cell(grid, r, c) == 4:
                closest_2 = next((n for n in dsl_neighbors4(r, c) if dsl_get_cell(grid, n[0], n[1]) == 2), None)
                if closest_2:
                    grid = dsl_set_cell(grid, closest_2[0], closest_2[1], 2)
        mask = dsl_mask_eq(grid, 4)
        grid = dsl_replace_color(grid, 4, 1)
        grid = dsl_paint_row(grid, 0, 0)
        for r, c in dsl_iter_coords(grid):
            if dsl_get_cell(grid, r, c) == 1:
                closest_2 = next((n for n in dsl_neighbors4(r, c) if dsl_get_cell(grid, n[0], n[1]) == 2), None)
                if closest_2:
                    grid = dsl_set_cell(grid, closest_2[0], closest_2[1], 2)
        mask = dsl_mask_eq(grid, 1)
        grid = dsl_replace_color(grid, 1, 0)
        grid = dsl_paint_row(grid, 0, 0)
        if grid == new_grid:
            break
    return grid