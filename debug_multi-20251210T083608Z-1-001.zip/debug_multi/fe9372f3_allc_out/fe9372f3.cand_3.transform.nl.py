from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    center = list(dsl_iter_coords(grid)).pop()
    grid = dsl_replace_color(grid, 2, 1)
    grid = dsl_replace_color(grid, 2, 8)
    grid = dsl_remap_colors(grid, {8: lambda x, y: dsl_get_cell(grid, x, y) + dsl_get_cell(grid, center[0], center[1]) + 1 - (abs(x - center[0]) + abs(y - center[1]))})
    grid = dsl_remap_colors(grid, {1: 1, 0: 0})
    if dsl_shape(grid)[0] % 2 == 1:
        grid = dsl_copy_row(grid, dsl_shape(grid)[0], dsl_zeros_like(grid))
    if dsl_shape(grid)[1] % 2 == 1:
        grid = dsl_copy_col(grid, dsl_shape(grid)[1], dsl_zeros_like(grid))
    return grid