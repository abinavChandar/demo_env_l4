from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    dsl_paint_row(dsl_paint_col(dsl_paint_cell(grid, r, c, 8), c, 8), r, 8)
    dsl_paint_row(dsl_paint_col(dsl_paint_cell(grid, r, c, 1), c, 1), r, 1)
    dsl_paint_row(dsl_paint_col(dsl_paint_cell(grid, r, c, 0), c, 0), r, 0)
    dsl_paint_row(dsl_paint_col(dsl_paint_cell(grid, r, c, 1 if dsl_in_bounds(grid, r, c) and (r == 0 or r == dsl_shape(grid)[0] - 1 or c == 0 or c == dsl_shape(grid)[1] - 1) else 0), c, 1 if dsl_in_bounds(grid, r, c) and (r == 0 or r == dsl_shape(grid)[0] - 1 or c == 0 or c == dsl_shape(grid)[1] - 1) else 0), c, 1 if dsl_in_bounds(grid, r, c) and (r == 0 or r == dsl_shape(grid)[0] - 1 or c == 0 or c == dsl_shape(grid)[1] - 1) else 0)
    return grid