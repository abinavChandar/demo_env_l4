from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    def process_row(r: int) -> List[List[int]]:
        top_row = dsl_get_row(grid, r)
        if dsl_any(top_row):
            return dsl_full(dsl_shape(grid)[0], dsl_shape(grid)[1], 0)
        first_non_zero = dsl_find_first(top_row, lambda x: x != 0)
        if first_non_zero is None:
            return grid
        output = dsl_clone(grid)
        dsl_paint_row(output, r, 0)
        dsl_paint_col(output, first_non_zero, 1)
        for c in dsl_iter_coords(output):
            if dsl_get_cell(output, c[0], c[1]) != 0:
                dsl_paint_col(output, c[1], 1)
        return output

    output = dsl_clone(grid)
    for r in dsl_iter_coords(output):
        output = process_row(r[0])
    return output