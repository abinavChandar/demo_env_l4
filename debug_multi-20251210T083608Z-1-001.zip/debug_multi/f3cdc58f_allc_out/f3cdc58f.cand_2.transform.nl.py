from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    non_zero = [x for x in dsl_iter_coords(grid) if dsl_get_cell(grid, x[0], x[1]) != 0]
    sorted_non_zero = sorted(non_zero, key=lambda x: dsl_get_cell(grid, x[0], x[1]))
    sorted_non_zero_dict = {x: i for i, x in enumerate(sorted_non_zero)}
    grid = dsl_remap_colors(grid, sorted_non_zero_dict)
    grid = dsl_paint_row(grid, 0, len(sorted_non_zero) - 1)
    grid = dsl_paint_col(grid, 0, len(sorted_non_zero) - 1)
    return grid