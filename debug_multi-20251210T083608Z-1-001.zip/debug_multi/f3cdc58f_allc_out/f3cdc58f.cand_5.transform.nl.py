from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    top_row = dsl_get_row(grid, 0)
    top_row = dsl_replace_color(top_row, 0, 0)
    top_row = dsl_paint_cell(top_row, dsl_get_first_non_zero(top_row), 1)
    grid = dsl_copy_row(grid, 0, 0)
    for r in range(1, dsl_shape(grid)[0]):
        row = dsl_get_row(grid, r)
        row = dsl_replace_color(row, 0, 0)
        first_non_zero = dsl_get_first_non_zero(row)
        row = dsl_paint_cell(row, first_non_zero, r + 1)
        grid = dsl_copy_row(grid, r, r)
    for c in dsl_iter_coords(grid):
        if dsl_get_cell(grid, c[0], c[1]) != 0:
            grid = dsl_paint_cell(grid, c[0], c[1], c[1] + 1)
    last_row = dsl_get_row(grid, dsl_shape(grid)[0] - 1)
    last_row = dsl_replace_color(last_row, 0, 0)
    last_row = dsl_paint_cell(last_row, dsl_get_first_non_zero(last_row), dsl_shape(grid)[0])
    grid = dsl_copy_row(grid, dsl_shape(grid)[0] - 1, dsl_shape(grid)[0] - 1)
    return grid