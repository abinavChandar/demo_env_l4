from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    top_left = next((r, c) for r, row in enumerate(grid) for c, val in enumerate(row) if val != 0)
    new_grid = dsl_zeros_like(grid)
    r, c = top_left
    for r2, row in enumerate(grid):
        for c2, val in enumerate(row):
            if dsl_in_bounds(grid, r2, c2):
                new_val = dsl_get_cell(grid, r2, c2) + 1 if dsl_get_cell(grid, r2, c2) > 0 else dsl_get_cell(grid, r2, c2)
                dsl_set_cell(new_grid, r2, c2, new_val)
                if r2 == r and c2 == c:
                    r, c = r2, c2
    return new_grid