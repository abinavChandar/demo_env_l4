from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    grid = dsl_paint_row(grid, 0, 1)
    for r in range(1, dsl_shape(grid)[0]):
        grid = dsl_paint_row(grid, r, 0)
    for r in range(dsl_shape(grid)[0] - 1, -1, -1):
        grid = dsl_paint_row(grid, r, 1)
    return grid