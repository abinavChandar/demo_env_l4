from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    non_zero_values = sorted([x for x in dsl_iter_coords(grid) if dsl_get_cell(grid, x[0], x[1]) != 0])
    sorted_values = [0] * len(non_zero_values)
    for i, x in enumerate(non_zero_values):
        sorted_values[i] = x
    output = dsl_zeros_like(grid)
    for r in dsl_iter_coords(grid):
        for c in dsl_neighbors4(r[0], r[1]):
            if dsl_in_bounds(grid, c[0], c[1]) and dsl_get_cell(grid, c[0], c[1]) != 0:
                dsl_set_cell(output, r[0], r[1], 1)
            elif dsl_in_bounds(grid, c[0], c[1]) and dsl_get_cell(grid, c[0], c[1]) == 0:
                if dsl_in_bounds(output, r[0], r[1]) and dsl_get_cell(output, r[0], r[1]) == 1:
                    dsl_set_cell(output, r[0], r[1], 1)
                else:
                    dsl_set_cell(output, r[0], r[1], 0)
    for r in dsl_iter_coords(output):
        for c in dsl_neighbors4(r[0], r[1]):
            if dsl_in_bounds(output, c[0], c[1]) and dsl_get_cell(output, c[0], c[1]) > 1:
                dsl_set_cell(output, c[0], c[1], dsl_get_cell(output, c[0], c[1]) + 1)
    return output