from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    sorted_values = sorted([x for row in grid for x in row if x != 0])
    mapping = {x: i for i, x in enumerate(sorted_values)}
    return dsl_remap_colors(dsl_zeros_like(grid, 0), mapping)