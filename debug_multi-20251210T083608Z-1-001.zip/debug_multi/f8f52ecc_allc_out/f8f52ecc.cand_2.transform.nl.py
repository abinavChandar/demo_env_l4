from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    output = dsl_clone(grid)
    top_left = dsl_get_cell(output, 0, 0)
    bottom_right = dsl_get_cell(output, dsl_shape(output)[0] - 1, dsl_shape(output)[1] - 1)
    for r, c in dsl_iter_coords(output):
        if 0 <= r - 1 < dsl_shape(output)[0] and 0 <= c < dsl_shape(output)[1]:
            output = dsl_set_cell(output, r, c, dsl_get_cell(grid, r - 1, c))
        elif r == 0 and c == 0:
            output = dsl_set_cell(output, r, c, top_left)
        elif r == dsl_shape(output)[0] - 1 and c == dsl_shape(output)[1] - 1:
            output = dsl_set_cell(output, r, c, bottom_right)
        else:
            output = dsl_set_cell(output, r, c, dsl_get_cell(grid, r - 1, c))
    center = dsl_crop(output, 1, 1, 3, 3)
    shifted_center = dsl_crop(output, 0, 0, 3, 3)
    for r, c in dsl_iter_coords(center):
        shifted_center = dsl_set_cell(shifted_center, r, c, dsl_get_cell(output, r + 1, c))
    output = dsl_paste_masked(output, shifted_center, 1, 1, dsl_mask_eq(center, dsl_get_cell(center, 1, 1)))
    return output