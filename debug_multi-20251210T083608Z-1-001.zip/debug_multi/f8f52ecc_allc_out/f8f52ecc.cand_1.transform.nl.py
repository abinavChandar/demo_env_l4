from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    middle_row = next(dsl_iter_coords(grid), None)
    if middle_row is None:
        return grid
    middle_row = list(middle_row)
    new_row = dsl_paint_row(dsl_clone(grid), middle_row[0], middle_row[1] + 1)
    grid = dsl_paint_row(grid, middle_row[0], new_row)
    return dsl_paint_row(grid, grid.shape[0] - 1, new_row)