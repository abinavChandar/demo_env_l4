from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    center = dsl_get_cell(dsl_clone(grid), dsl_shape(grid)[0] // 2, dsl_shape(grid)[1] // 2)
    if center == 8:
        grid = dsl_replace_color(grid, 8, 2)
    elif center == 9:
        grid = dsl_replace_color(grid, 9, 9)
    elif center == 2:
        grid = dsl_replace_color(grid, 2, 2)
    elif center == 6:
        grid = dsl_replace_color(grid, 6, 6)
    elif center == 4:
        grid = dsl_replace_color(grid, 4, 4)
    grid = dsl_replace_color(grid, 1, 1)
    grid = dsl_replace_color(grid, 2, 2)
    grid = dsl_replace_color(grid, 4, 4)
    grid = dsl_replace_color(grid, 5, 5)
    grid = dsl_replace_color(grid, 6, 6)
    grid = dsl_replace_color(grid, 7, 7)
    grid = dsl_replace_color(grid, 8, 8)
    grid = dsl_replace_color(grid, 9, 9)
    grid = dsl_replace_color(grid, 3, 3)
    return grid