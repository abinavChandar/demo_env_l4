from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    frame = dsl_bbox_of_mask(dsl_mask_eq(grid, 0))
    target_row = dsl_crop(grid, frame[0] + 1, frame[1] + 1, 1, dsl_shape(grid)[1])
    target_row = dsl_paint_row(target_row, frame[0] + 1, target_row)
    for r, c in dsl_iter_coords(target_row):
        if dsl_get_cell(target_row, r, c) == 1:
            target_row = dsl_set_cell(target_row, r, c, dsl_get_cell(target_row, r - 1, c))
        elif dsl_get_cell(target_row, r, c) == 2:
            target_row = dsl_set_cell(target_row, r, c, dsl_if(dsl_get_cell(target_row, r - 1, c) == 2, dsl_get_cell(target_row, r - 1, c), dsl_get_cell(target_row, r - 1, c - 1)))
        elif dsl_get_cell(target_row, r, c) == 8:
            target_row = dsl_set_cell(target_row, r, c, dsl_if(dsl_get_cell(target_row, r - 1, c) == 8, dsl_get_cell(target_row, r - 1, c), dsl_get_cell(target_row, r - 1, c - 1)))
        elif dsl_get_cell(target_row, r, c) == 6:
            target_row = dsl_set_cell(target_row, r, c, dsl_if(dsl_get_cell(target_row, r - 1, c) == 6, dsl_get_cell(target_row, r - 1, c), dsl_get_cell(target_row, r - 1, c - 1)))
        elif dsl_get_cell(target_row, r, c) == 9:
            target_row = dsl_set_cell(target_row, r, c, dsl_get_cell(target_row, r - 1, c))
        elif dsl_get_cell(target_row, r, c) == 4:
            target_row = dsl_set_cell(target_row, r, c, dsl_get_cell(target_row, r - 1, c))
        elif dsl_get_cell(target_row, r, c) == 7:
            target_row = dsl_set_cell(target_row, r, c, dsl_get_cell(target_row, r - 1, c))
        elif dsl_get_cell(target_row, r, c) == 5:
            target_row = dsl_set_cell(target_row, r, c, dsl_get_cell(target_row, r - 1, c))
        elif dsl_get_cell(target_row, r, c) == 3:
            target_row = dsl_set_cell(target_row, r, c, dsl_get_cell(target_row, r - 1, c))
    return dsl_paste_masked(grid, target_row, frame[0] + 1, frame[1] + 1, dsl_mask_eq(target_row, 0))