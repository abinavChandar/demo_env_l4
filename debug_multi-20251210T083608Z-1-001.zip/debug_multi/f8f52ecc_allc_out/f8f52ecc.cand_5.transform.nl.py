from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    mask = dsl_mask_eq(grid, 8)
    grid = dsl_paint_cell(grid, 0, 0, dsl_get_cell(grid, 0, 0))
    grid = dsl_paint_row(grid, 1, dsl_get_cell(grid, 0, 0))
    grid = dsl_paint_row(grid, len(grid) - 2, dsl_get_cell(grid, 0, 0))
    grid = dsl_paint_row(grid, len(grid) - 3, dsl_get_cell(grid, 0, 0))
    grid = dsl_paint_row(grid, len(grid) - 3, dsl_get_cell(grid, 0, 0))
    grid = dsl_paint_row(grid, len(grid) - 3, dsl_get_cell(grid, 0, 0))
    grid = dsl_paint_row(grid, len(grid) - 3, dsl_get_cell(grid, 0, 0))
    grid = dsl_paint_row(grid, len(grid) - 3, dsl_get_cell(grid, 0, 0))
    grid = dsl_paint_row(grid, len(grid) - 3, dsl_get_cell(grid, 0, 0))
    grid = dsl_paint_row(grid, len(grid) - 3, dsl_get_cell(grid, 0, 0))
    grid = dsl_paint_row(grid, len(grid) - 3, dsl_get_cell(grid, 0, 0))
    grid = dsl_paint_row(grid, len(grid) - 3, dsl_get_cell(grid, 0, 0))
    grid = dsl_paint_row(grid, len(grid) - 3, dsl_get_cell(grid, 0, 0))
    return grid