from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    boundary = dsl_mask_eq(grid, 1)
    grid = dsl_paint_row(grid, 0, 1)
    grid = dsl_paint_row(grid, len(grid) - 1, 1)
    grid = dsl_paint_col(grid, 0, 1)
    grid = dsl_paint_col(grid, len(grid[0]) - 1, 1)

    for r, c in dsl_iter_coords(grid):
        if not dsl_in_bounds(boundary, r, c):
            if dsl_get_cell(grid, r, c) == 2:
                grid = dsl_paint_cell(grid, r, c, 2)
            elif dsl_get_cell(grid, r, c) == 6:
                neighbors = dsl_neighbors4(r, c)
                if all(dsl_get_cell(grid, nr, nc) == 6 for nr, nc in neighbors):
                    grid = dsl_paint_cell(grid, r, c, 6)
                else:
                    grid = dsl_paint_cell(grid, r, c, 8)
            elif dsl_get_cell(grid, r, c) == 8:
                neighbors = dsl_neighbors4(r, c)
                if all(dsl_get_cell(grid, nr, nc) == 8 for nr, nc in neighbors):
                    grid = dsl_paint_cell(grid, r, c, 8)
                else:
                    grid = dsl_paint_cell(grid, r, c, 2)
            elif dsl_get_cell(grid, r, c) == 9:
                grid = dsl_paint_cell(grid, r, c, 9)
            elif dsl_get_cell(grid, r, c) == 4:
                grid = dsl_paint_cell(grid, r, c, 4)
            elif dsl_get_cell(grid, r, c) == 5:
                grid = dsl_paint_cell(grid, r, c, 5)
            elif dsl_get_cell(grid, r, c) == 7:
                grid = dsl_paint_cell(grid, r, c, 7)
            elif dsl_get_cell(grid, r, c) == 1:
                grid = dsl_paint_cell(grid, r, c, 1)
            elif dsl_get_cell(grid, r, c) == 3:
                grid = dsl_paint_cell(grid, r, c, 3)
            elif dsl_get_cell(grid, r, c) == 6 and any(dsl_get_cell(grid, nr, nc) == 3 for nr, nc in dsl_neighbors4(r, c)):
                grid = dsl_paint_cell(grid, r, c, 6)
            elif dsl_get_cell(grid, r, c) == 4 and any(dsl_get_cell(grid, nr, nc) == 3 for nr, nc in dsl_neighbors4(r, c)):
                grid = dsl_paint_cell(grid, r, c, 4)
    return grid