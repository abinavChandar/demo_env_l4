from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    def replace_square(grid: List[List[int]], value: int, new_value: int) -> List[List[int]]:
        mask = dsl_mask_eq(grid, value)
        new_grid = dsl_paint_masked(grid, dsl_full(4, 4, new_value), 0, 0, mask)
        return new_grid

    def replace_square_3x3(grid: List[List[int]], value: int, new_value: int) -> List[List[int]]:
        mask = dsl_mask_eq(grid, value)
        new_grid = dsl_paint_masked(grid, dsl_full(3, 3, new_value), 0, 0, mask)
        return new_grid

    grid = replace_square(grid, 4, 5)
    while True:
        new_grid = dsl_paint_masked(grid, dsl_full(4, 4, 5), 0, 0, dsl_mask_eq(grid, 4))
        if new_grid == grid:
            break
        grid = new_grid

    grid = replace_square_3x3(grid, 3, 2)
    while True:
        new_grid = dsl_paint_masked(grid, dsl_full(3, 3, 2), 0, 0, dsl_mask_eq(grid, 3))
        if new_grid == grid:
            break
        grid = new_grid

    grid = dsl_replace_color(grid, 8, 0)
    grid = dsl_replace_color(grid, 7, 0)
    grid = dsl_replace_color(grid, 6, 0)
    grid = dsl_replace_color(grid, 2, 0)
    grid = replace_square(grid, 2, 2)
    grid = dsl_replace_color(grid, 1, 0)
    grid = dsl_replace_color(grid, 0, 0)
    return grid