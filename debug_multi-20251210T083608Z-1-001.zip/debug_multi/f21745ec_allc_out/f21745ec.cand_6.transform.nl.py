from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    mask = dsl_mask_eq(grid, 0)
    grid = dsl_replace_color(dsl_clone(grid), 0, 0)
    inner_grid = dsl_crop(grid, 1, 1, dsl_shape(grid)[0] - 2, dsl_shape(grid)[1] - 2)
    grid = dsl_paint_row(grid, 0, 0)
    grid = dsl_paint_row(grid, dsl_shape(grid)[0] - 1, 0)
    grid = dsl_paint_col(grid, 0, 0)
    grid = dsl_paint_col(grid, dsl_shape(grid)[1] - 1, 0)
    for r, c in dsl_iter_coords(inner_grid):
        if dsl_get_cell(inner_grid, r, c) == 3:
            grid = dsl_paint_cell(grid, r + 1, c + 1, 3)
        elif dsl_get_cell(inner_grid, r, c) == 2:
            grid = dsl_paint_cell(grid, r + 1, c + 1, 2)
        elif dsl_get_cell(inner_grid, r, c) == 8:
            grid = dsl_paint_cell(grid, r + 1, c + 1, 8)
        elif dsl_get_cell(inner_grid, r, c) == 4:
            grid = dsl_paint_cell(grid, r + 1, c + 1, 4)
        elif dsl_get_cell(inner_grid, r, c) == 5:
            grid = dsl_paint_cell(grid, r + 1, c + 1, 5)
        elif dsl_get_cell(inner_grid, r, c) == 6:
            grid = dsl_paint_cell(grid, r + 1, c + 1, 6)
        elif dsl_get_cell(inner_grid, r, c) == 7:
            grid = dsl_paint_cell(grid, r + 1, c + 1, 7)
        elif dsl_get_cell(inner_grid, r, c) == 1:
            grid = dsl_paint_cell(grid, r + 1, c + 1, 1)
    return grid