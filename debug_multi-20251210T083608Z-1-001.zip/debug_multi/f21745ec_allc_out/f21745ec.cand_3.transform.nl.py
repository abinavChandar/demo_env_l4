from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    top_bottom = dsl_mask_eq(dsl_bbox_of_mask(dsl_mask_eq(grid, 3)), 0)
    grid = dsl_paint_row(dsl_paint_col(grid, 3, 2 if dsl_in_bounds(grid, r, c) and top_bottom else 3), 3, 2 if top_bottom else 3)
    grid = dsl_replace_color(grid, 4, 0)
    grid = dsl_replace_color(grid, 7, 0)
    grid = dsl_replace_color(grid, 5, 0)
    grid = dsl_replace_color(grid, 6, 0)
    grid = dsl_replace_color(grid, 1, 0)
    grid = dsl_replace_color(grid, 0, 0)
    grid = dsl_replace_color(grid, 2, 0)
    grid = dsl_replace_color(grid, 3, 0)
    grid = dsl_replace_color(grid, 8, 0)
    return grid