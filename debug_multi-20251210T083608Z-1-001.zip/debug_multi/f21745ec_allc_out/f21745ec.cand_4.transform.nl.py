from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    outer = dsl_bbox_of_mask(dsl_mask_eq(grid, 8))
    h, w = dsl_shape(grid)
    color = 2
    while True:
        inner = dsl_bbox_of_mask(dsl_mask_eq(dsl_crop(grid, *outer, w // 3, w // 3), 8))
        dsl_fill_rect(grid, *inner, w // 3, 2, color)
        outer = dsl_bbox_of_mask(dsl_mask_eq(dsl_crop(grid, *outer, w // 3, w // 3), 8))
        if outer is None:
            break
        color = 3 - color
    for width in [3, 2, 1, 7, 4, 5, 6]:
        inner = dsl_bbox_of_mask(dsl_mask_eq(dsl_crop(grid, *outer, width, width), 8))
        dsl_set_cell(grid, *inner, 0)
        outer = dsl_bbox_of_mask(dsl_mask_eq(dsl_crop(grid, *outer, width, width), 8))
    return grid