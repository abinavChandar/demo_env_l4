from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    central_square = dsl_crop(grid, *dsl_bbox_of_mask(dsl_mask_eq(grid, dsl_get_cell(grid, *next(dsl_iter_coords(grid))))))
    rotated_region = dsl_rot90(central_square)
    new_grid = dsl_paste(grid, rotated_region, *dsl_bbox_of_mask(dsl_mask_eq(grid, dsl_get_cell(grid, *next(dsl_iter_coords(grid))))))
    return dsl_zeros_like(new_grid, 0)