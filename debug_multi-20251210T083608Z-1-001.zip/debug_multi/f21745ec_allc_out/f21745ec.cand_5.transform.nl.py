from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    outer_frame = dsl_mask_eq(dsl_mask_eq(grid, 4), 8)
    inner_frame = dsl_mask_eq(dsl_mask_eq(grid, 3), outer_frame)
    sub_frame = dsl_mask_eq(dsl_mask_eq(grid, 2), inner_frame)
    grid = dsl_replace_color(dsl_replace_color(dsl_replace_color(dsl_replace_color(grid, 2, 1), 3, 2), 4, 0), 8, 0)
    grid = dsl_replace_color(grid, 5, 1)
    grid = dsl_replace_color(grid, 6, 2)
    grid = dsl_replace_color(grid, 7, 1)
    grid = dsl_replace_color(grid, 8, 8)
    grid = dsl_replace_color(grid, 0, 0)
    return grid