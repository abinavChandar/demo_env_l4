from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    target_value = dsl_get_cell(grid, *dsl_bbox_of_mask(dsl_mask_eq(grid, dsl_get_cell(grid, *next(dsl_iter_coords(grid)))))[0])
    bounding_box = dsl_bbox_of_mask(dsl_mask_eq(grid, target_value))
    output_grid = dsl_full(*bounding_box[2:], target_value)
    return output_grid