from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    max_val = dsl_max(dsl_filter(dsl_iter_coords(grid), lambda r, c: dsl_get_cell(grid, r, c) != 0))
    target = dsl_max([max_val, 0])
    return dsl_full(dsl_shape(grid)[1], dsl_shape(grid)[0], target)