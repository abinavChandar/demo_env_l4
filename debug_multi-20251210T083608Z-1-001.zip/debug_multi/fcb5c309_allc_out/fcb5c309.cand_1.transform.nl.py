from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    top_row = next((r for r in grid if any(r)), [])
    output = dsl_full(dsl_shape(grid)[0], dsl_shape(grid)[1], dsl_get_cell(top_row, 0))
    return output