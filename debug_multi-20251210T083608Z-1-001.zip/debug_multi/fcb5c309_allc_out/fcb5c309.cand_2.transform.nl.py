from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    target_value = dsl_get_cell(grid, *dsl_bbox_of_mask(dsl_mask_eq(grid, dsl_get_cell(grid, *dsl_iter_coords(grid)[0]))))
    mask = dsl_mask_eq(grid, target_value)
    bounding_box = dsl_bbox_of_mask(mask)
    if bounding_box is not None:
        r0, c0, r1, c1 = bounding_box
        dsl_fill_rect(grid, r0, c0, r1 - r0 + 1, c1 - c0 + 1, target_value)
        dsl_crop(grid, r0, c0, r1 - r0 + 1, c1 - c0 + 1)
    return grid