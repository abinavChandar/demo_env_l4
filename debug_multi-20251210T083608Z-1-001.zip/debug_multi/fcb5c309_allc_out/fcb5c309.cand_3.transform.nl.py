from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    target = dsl_mask_eq(grid, 0)[0][0]
    bbox = dsl_bbox_of_mask(dsl_mask_eq(grid, target))
    sub_grid = dsl_crop(grid, bbox[0], bbox[1], bbox[2] - bbox[0], bbox[3] - bbox[1])
    grid = dsl_replace_color(grid, target, dsl_zeros_like(sub_grid))
    sub_grid = dsl_rot90(dsl_rot90(sub_grid, 3), 1)
    while dsl_shape(sub_grid)[0] < dsl_shape(grid)[0] or dsl_shape(sub_grid)[1] < dsl_shape(grid)[1]:
        sub_grid = dsl_rot90(sub_grid, 1)
    grid = dsl_paste(grid, sub_grid, 0, 0)
    return grid