from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    top_row = next((r for r in dsl_iter_coords(grid) if any(c != 0 for c in r[1])), None)
    if top_row is None:
        return dsl_zeros_like(grid[0])
    new_grid = dsl_full(len(grid), 1, top_row[1])
    return dsl_crop(new_grid, 0, 0, len(grid), 1)