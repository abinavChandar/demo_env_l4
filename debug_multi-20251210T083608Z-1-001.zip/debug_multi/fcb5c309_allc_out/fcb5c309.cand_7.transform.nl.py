from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    non_zero_values = [dsl_get_cell(G, r, c) for r, c in dsl_iter_coords(grid) if dsl_get_cell(G, r, c) != 0]
    max_x, max_y = dsl_bbox_of_mask(dsl_mask_eq(G, non_zero_values[0]))[2:]
    new_grid = dsl_full(max_y, max_x, val=non_zero_values[0])
    return new_grid