from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    topmost_row = next((r for r in dsl_iter_coords(grid) if any(c != 0 for c in dsl_get_cell(grid, r, c) for c in range(dsl_shape(grid)[1]))), None)
    if topmost_row is not None:
        dsl_set_cell(grid, topmost_row, 0, dsl_get_cell(grid, topmost_row, 0))
        grid = dsl_crop(grid, 0, 0, topmost_row + 1, dsl_shape(grid)[1])
    return grid