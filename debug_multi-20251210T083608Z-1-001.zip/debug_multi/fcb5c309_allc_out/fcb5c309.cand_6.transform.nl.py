from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    top_row = dsl_paint_row(grid, 0, dsl_get_cell(grid, 0, dsl_iter_coords(grid).next()[1]))
    non_zero_values = dsl_mask_eq(top_row, 0)
    non_zero_count = dsl_shape(non_zero_values)[1]
    output_grid = dsl_full(non_zero_count, 1, dsl_get_cell(grid, 0, dsl_iter_coords(grid).next()[1]))
    return output_grid