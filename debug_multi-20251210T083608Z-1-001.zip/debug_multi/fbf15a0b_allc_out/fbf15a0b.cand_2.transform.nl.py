from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    return dsl_rot90(dsl_rot90(grid, k=1), k=1)