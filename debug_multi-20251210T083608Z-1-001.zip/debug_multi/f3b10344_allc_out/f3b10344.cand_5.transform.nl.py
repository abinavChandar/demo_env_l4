from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    grid = dsl_replace_color(grid, 0, 8)
    return grid