from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    return dsl_zeros_like(grid, 8)