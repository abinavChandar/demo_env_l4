from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    grid = dsl_zeros_like(grid, val=0)
    grid = dsl_paint_row(grid, 8, 0)
    return grid