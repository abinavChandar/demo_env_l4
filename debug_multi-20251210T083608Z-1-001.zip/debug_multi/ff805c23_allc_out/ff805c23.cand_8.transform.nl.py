from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    for r in range(dsl_shape(grid)[0] - 1):
        top_row = dsl_copy_row(grid, r, r)
        dsl_set_cell(top_row, 0, 0, 0)
        dsl_set_cell(top_row, 0, 1, 6)
        for c in dsl_iter_coords(top_row):
            if dsl_get_cell(top_row, c[0], c[1]) != 0:
                dsl_set_cell(top_row, c[0], c[1], 0)
            elif dsl_get_cell(top_row, c[0], c[1]) == 0:
                dsl_set_cell(top_row, c[0], c[1], 6)
        dsl_set_row(grid, r, top_row)
    bottom_row = dsl_copy_row(grid, dsl_shape(grid)[0] - 1, dsl_shape(grid)[0] - 1)
    dsl_set_cell(bottom_row, 0, 0, 0)
    dsl_set_cell(bottom_row, 0, 1, 6)
    for c in dsl_iter_coords(bottom_row):
        if dsl_get_cell(bottom_row, c[0], c[1]) != 0:
            dsl_set_cell(bottom_row, c[0], c[1], 0)
        elif dsl_get_cell(bottom_row, c[0], c[1]) == 0:
            dsl_set_cell(bottom_row, c[0], c[1], 6)
    dsl_set_row(grid, dsl_shape(grid)[0] - 1, bottom_row)
    return grid