from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    shape = dsl_shape(grid)
    roi_shape = dsl_bbox_of_mask(dsl_mask_eq(grid, dsl_get_cell(grid, *dsl_iter_coords(grid)[0])))
    roi_color = set(dsl_iter_coords(dsl_mask_eq(grid, dsl_get_cell(grid, *dsl_iter_coords(grid)[0]))))
    if len(roi_color) == 1:
        grid = dsl_replace_color(grid, list(roi_color)[0], 6)
    elif len(roi_color) > 1:
        grid = dsl_replace_color(grid, list(roi_color)[0], 0)
        grid = dsl_replace_color(grid, list(roi_color)[1], 6)
    return grid