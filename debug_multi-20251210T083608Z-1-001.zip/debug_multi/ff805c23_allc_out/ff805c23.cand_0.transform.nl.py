from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    outer = dsl_bbox_of_mask(dsl_mask_eq(grid, dsl_get_cell(grid, 0, 0)))
    inner = dsl_bbox_of_mask(dsl_mask_eq(grid, dsl_get_cell(grid, outer[0], outer[1])))
    solid = dsl_full(inner[2] - inner[0], inner[3] - inner[1], dsl_get_cell(grid, inner[0], inner[1]))
    result = dsl_crop(grid, outer[0], outer[1], outer[2] - outer[0], outer[3] - outer[1])
    result = dsl_paint_rect(result, inner[0], inner[1], inner[2] - inner[0], inner[3] - inner[1], dsl_get_cell(grid, inner[0], inner[1]))
    result = dsl_crop(result, 0, 0, outer[2] - outer[0], outer[3] - outer[1])
    return result