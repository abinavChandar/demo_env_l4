from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    for r in dsl_iter_coords(grid):
        if dsl_in_bounds(grid, r[0], 0):
            first_val = dsl_get_cell(grid, r[0], 0)
            grid = dsl_paint_row(grid, r[0], first_val)
    return grid