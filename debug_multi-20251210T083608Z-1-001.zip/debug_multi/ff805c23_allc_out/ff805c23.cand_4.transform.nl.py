from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    r0, c0, h, w = dsl_bbox_of_mask(dsl_mask_eq(grid, 6))
    inner = dsl_crop(grid, r0, c0, h, w)
    solid = dsl_fill_rect(dsl_zeros_like(grid, 6), r0, c0, h, w, 6)
    return dsl_replace_color(dsl_paint_row(dsl_paint_col(dsl_paint_cell(solid, r0, c0, 6), c0, 6), r0, 6), r0, 6)