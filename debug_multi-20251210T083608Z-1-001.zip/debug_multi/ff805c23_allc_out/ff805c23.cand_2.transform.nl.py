from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    outer = dsl_bbox_of_mask(dsl_mask_eq(grid, 0))
    inner = dsl_crop(grid, (outer[0] + 2), (outer[1] + 2), 5, 5)
    inner = dsl_fill_rect(inner, 0, 0, 5, 5, 6)
    inner = dsl_mask_eq(inner, 6)
    inner = dsl_zeros_like(grid, 6)
    inner = dsl_paint_row(inner, 0, 6)
    inner = dsl_paint_row(inner, 4, 6)
    inner = dsl_paint_col(inner, 0, 6)
    inner = dsl_paint_col(inner, 4, 6)
    inner = dsl_mask_eq(inner, 6)
    size = dsl_shape(inner)
    if size[0] != size[1]:
        inner = dsl_zeros_like(grid, 6)
        inner = dsl_paint_row(inner, 0, 6)
        inner = dsl_paint_row(inner, size[0] - 1, 6)
        inner = dsl_paint_col(inner, 0, 6)
        inner = dsl_paint_col(inner, size[1] - 1, 6)
    return inner