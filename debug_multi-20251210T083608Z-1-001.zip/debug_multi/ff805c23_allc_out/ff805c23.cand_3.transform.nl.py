from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    outermost = dsl_bbox_of_mask(dsl_mask_eq(grid, 0))
    innermost = dsl_crop(grid, *outermost)
    width = dsl_shape(innermost)[1]
    if width >= 5:
        innermost = dsl_fill_rect(innermost, 0, 0, *dsl_shape(innermost), 6)
    else:
        innermost = dsl_fill_rect(innermost, 0, 0, *dsl_shape(innermost), 0)
    outermost = dsl_bbox_of_mask(dsl_mask_eq(grid, 0))
    grid = dsl_paste_masked(grid, innermost, *outermost)
    grid = dsl_fill_rect(grid, *outermost, *dsl_shape(grid), 0)
    return grid