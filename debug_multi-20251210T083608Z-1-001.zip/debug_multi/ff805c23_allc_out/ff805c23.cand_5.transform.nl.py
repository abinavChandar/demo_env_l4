from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    outer_bbox = dsl_bbox_of_mask(dsl_mask_eq(grid, dsl_get_cell(grid, *next(dsl_iter_coords(grid)))))
    outer_region = dsl_crop(grid, *outer_bbox)
    output_region = dsl_zeros_like(grid)
    output_region = dsl_paint_row(output_region, 0, dsl_get_cell(outer_region, 0, 0))
    output_region = dsl_paint_col(output_region, 0, dsl_get_cell(outer_region, 0, 0))
    output_region = dsl_paint_row(output_region, dsl_shape(output_region)[0] - 1, dsl_get_cell(outer_region, 0, 0))
    output_region = dsl_paint_col(output_region, dsl_shape(output_region)[1] - 1, dsl_get_cell(outer_region, 0, 0))
    inner_bbox = dsl_bbox_of_mask(dsl_mask_eq(grid, dsl_get_cell(grid, *next(dsl_iter_coords(grid)))))
    inner_region = dsl_crop(grid, *inner_bbox)
    grid = dsl_paste_masked(grid, output_region, *inner_bbox, dsl_mask_eq(grid, dsl_get_cell(grid, *next(dsl_iter_coords(grid)))))
    grid = dsl_fill_rect(grid, *outer_bbox, dsl_shape(outer_bbox)[0], dsl_shape(outer_bbox)[1], dsl_get_cell(outer_region, 0, 0))
    return grid