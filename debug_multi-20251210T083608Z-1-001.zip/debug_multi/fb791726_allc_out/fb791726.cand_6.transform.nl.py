from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    center_r, center_c = next(dsl_iter_coords(grid))
    if dsl_get_cell(grid, center_r, center_c) != 0:
        new_grid = dsl_zeros_like(grid, 0)
        new_grid = dsl_paint_row(new_grid, 0, 0)
        new_grid = dsl_paint_row(new_grid, len(grid), 0)
        new_grid = dsl_paint_col(new_grid, 0, 0)
        new_grid = dsl_paint_col(new_grid, 0, len(grid[0]))
        for r in range(len(grid)):
            for c in range(len(grid[0])):
                if r == center_r or c == center_c:
                    new_grid = dsl_set_cell(new_grid, r, c, dsl_get_cell(grid, center_r, center_c))
                elif r == 0 or r == len(grid) - 1 or c == 0 or c == len(grid[0]) - 1:
                    new_grid = dsl_set_cell(new_grid, r, c, 3)
                else:
                    new_grid = dsl_set_cell(new_grid, r, c, dsl_get_cell(grid, r, c))
        return new_grid
    else:
        return grid