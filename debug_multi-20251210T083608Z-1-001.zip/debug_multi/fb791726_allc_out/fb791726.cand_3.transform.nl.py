from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    while True:
        center_r, center_c = next(dsl_iter_coords(grid))
        if dsl_get_cell(grid, center_r, center_c) != 0:
            if dsl_get_cell(grid, center_r - 1, center_c) == 0:
                grid = dsl_paint_row(grid, center_r - 1, 3)
            if dsl_get_cell(grid, center_r + 1, center_c) == 0:
                grid = dsl_paint_row(grid, center_r + 1, 3)
        else:
            if dsl_get_cell(grid, center_r - 1, center_c) == 0 or dsl_get_cell(grid, center_r + 1, center_c) == 0:
                grid = dsl_paint_row(grid, center_r - 1, 3)
                grid = dsl_paint_row(grid, center_r + 1, 3)
            else:
                grid = dsl_paint_row(grid, center_r - 1, 3)
                grid = dsl_paint_row(grid, center_r, 8)
                grid = dsl_paint_row(grid, center_r + 1, 3)
                grid = dsl_paint_row(grid, center_r + 2, 3)
        if dsl_shape(grid) == (center_r + 3, center_c + 1):
            break
    return grid