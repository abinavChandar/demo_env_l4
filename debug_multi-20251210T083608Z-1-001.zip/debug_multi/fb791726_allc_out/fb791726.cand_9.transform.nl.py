from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    target = dsl_get_cell(grid, *dsl_bbox_of_mask(dsl_mask_eq(grid, dsl_get_cell(grid, 0, 0)))[0])
    output = dsl_zeros_like(grid)
    for r, c in dsl_iter_coords(grid):
        if dsl_get_cell(grid, r, c) == target:
            output = dsl_paint_row(output, r, target)
            output = dsl_paint_row(output, r + 1, target)
            if r > 0 and r < dsl_shape(grid)[0] - 1:
                output = dsl_paint_row(output, r - 1, target)
                output = dsl_paint_row(output, r + 2, target)
    return output