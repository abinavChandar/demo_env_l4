from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    target = dsl_get_cell(grid, 0, 0)
    new_grid = dsl_full(3, dsl_shape(grid)[1], target)
    new_grid = dsl_copy_row(new_grid, 0, 0)
    new_grid = dsl_copy_row(new_grid, 0, 1)
    new_grid = dsl_copy_row(new_grid, 0, 2)
    new_grid = dsl_copy_col(new_grid, 0, 0)
    new_grid = dsl_copy_col(new_grid, 0, 1)
    new_grid = dsl_copy_col(new_grid, 0, 2)
    new_grid = dsl_paste_masked(new_grid, grid, 3, 0, dsl_component_mask(new_grid, 3, 0))
    new_grid = dsl_paste_masked(new_grid, grid, 3, 1, dsl_component_mask(new_grid, 3, 1))
    new_grid = dsl_paste_masked(new_grid, grid, 3, 2, dsl_component_mask(new_grid, 3, 2))
    new_grid = dsl_paste_masked(new_grid, grid, 4, 0, dsl_component_mask(new_grid, 4, 0))
    new_grid = dsl_paste_masked(new_grid, grid, 4, 1, dsl_component_mask(new_grid, 4, 1))
    new_grid = dsl_paste_masked(new_grid, grid, 4, 2, dsl_component_mask(new_grid, 4, 2))
    return new_grid