from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    center_r, center_c = next(dsl_iter_coords(grid))
    center_val = dsl_get_cell(grid, center_r, center_c)
    new_grid = dsl_zeros_like(grid, 0)
    new_grid = dsl_paint_row(new_grid, 0, 3)
    new_grid = dsl_paint_row(new_grid, len(grid) - 1, 3)
    new_grid = dsl_paint_col(new_grid, center_c, center_val)
    new_grid = dsl_paint_row(new_grid, 0, 0)
    new_grid = dsl_paint_row(new_grid, len(grid) - 1, 0)
    new_grid = dsl_paint_row(new_grid, 0, 3)
    new_grid = dsl_paint_row(new_grid, 0, center_val)
    new_grid = dsl_paint_row(new_grid, 0, 0)
    new_grid = dsl_paint_row(new_grid, len(grid) - 1, 3)
    new_grid = dsl_paint_row(new_grid, len(grid) - 1, center_val)
    new_grid = dsl_paint_row(new_grid, len(grid) - 1, 0)
    new_grid = dsl_paste(new_grid, grid, 1, 0)
    new_grid = dsl_paste(new_grid, grid, 1, len(grid[0]))
    new_grid = dsl_paint_row(new_grid, 1, 3)
    new_grid = dsl_paint_row(new_grid, 1, center_val)
    new_grid = dsl_paint_row(new_grid, 1, 0)
    return new_grid