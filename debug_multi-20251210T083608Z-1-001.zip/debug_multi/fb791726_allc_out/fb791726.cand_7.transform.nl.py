from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    center_r, center_c = next((r, c) for r, row in enumerate(grid) for c, val in enumerate(row) if val != 0)
    center_val = dsl_get_cell(grid, center_r, center_c)
    output = dsl_full(6, 12, 3)
    for _ in range(6):
        dsl_paint_row(output, 0, center_val)
        dsl_paint_row(output, 5, center_val)
        dsl_paint_col(output, 0, center_val)
        dsl_paint_col(output, 11, center_val)
    return output