from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    target = dsl_get_cell(grid, 0, 0)
    new_grid = dsl_full(dsl_shape(grid)[0] + 2, dsl_shape(grid)[1] + 2, target)
    new_grid = dsl_paint_row(new_grid, 0, target)
    new_grid = dsl_paint_row(new_grid, dsl_shape(grid)[0] + 1, target)
    new_grid = dsl_paint_col(new_grid, 0, target)
    new_grid = dsl_paint_col(new_grid, dsl_shape(grid)[1] + 1, target)
    return new_grid