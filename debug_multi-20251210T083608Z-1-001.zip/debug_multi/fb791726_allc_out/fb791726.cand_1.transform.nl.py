from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    target = dsl_get_cell(grid, 0, 0)
    new_grid = dsl_full(3, dsl_shape(grid)[1], target)
    new_grid = dsl_paste(new_grid, grid, 1, 0)
    new_grid = dsl_paste(new_grid, dsl_full(3, dsl_shape(grid)[1], target), dsl_shape(grid)[0] + 2, 0)
    new_grid = dsl_paste(new_grid, dsl_full(dsl_shape(grid)[0], 3, target), 0, 1)
    new_grid = dsl_paste(new_grid, dsl_full(dsl_shape(grid)[0], 3, target), 0, dsl_shape(grid)[1] + 2)
    if target == 8:
        new_grid = dsl_paste(new_grid, dsl_full(3, dsl_shape(grid)[1], target), dsl_shape(grid)[0] + 4, 1)
        new_grid = dsl_paste(new_grid, dsl_full(3, dsl_shape(grid)[1], target), dsl_shape(grid)[0] + 2, dsl_shape(grid)[1] + 3)
    elif target == 4:
        new_grid = dsl_paste(new_grid, dsl_full(3, dsl_shape(grid)[1], target), dsl_shape(grid)[0] + 4, dsl_shape(grid)[1] + 3)
        new_grid = dsl_paste(new_grid, dsl_full(3, dsl_shape(grid)[1], target), dsl_shape(grid)[0] + 2, 1)
    if target == 7:
        new_grid = dsl_paste(new_grid, dsl_full(dsl_shape(grid)[0], 1, target), dsl_shape(grid)[0] + 5, dsl_shape(grid)[1] + 3)
        new_grid = dsl_paste(new_grid, dsl_full(dsl_shape(grid)[0], 1, target), dsl_shape(grid)[0] + 1, dsl_shape(grid)[1] + 3)
    return new_grid