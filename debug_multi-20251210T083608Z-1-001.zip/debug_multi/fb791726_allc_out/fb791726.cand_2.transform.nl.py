from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    target = 8
    grid = dsl_paint_row(dsl_paint_row(dsl_paint_col(dsl_paint_col(dsl_paint_row(dsl_paint_row(grid, target, 0, 0), target, 0, 0), target, 0, 0), target, 0, 0), target, 0, 0), target, 0, 0)
    return grid