from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    top_row = dsl_get_row(grid, 0)
    max_val = max(top_row)
    sorted_top_row = sorted(top_row, reverse=True)
    for r in dsl_iter_coords(grid):
        if dsl_get_row(grid, r) != top_row:
            continue
        new_row = dsl_paint_row(dsl_zeros_like(grid, 0), r, max_val)
        max_val = max_val - 1
        if max_val < 0:
            max_val = 0
        grid = dsl_replace_row(grid, r, new_row)
    return grid