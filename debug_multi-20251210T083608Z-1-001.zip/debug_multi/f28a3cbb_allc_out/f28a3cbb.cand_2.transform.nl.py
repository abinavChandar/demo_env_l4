from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    def dsl_paint_row(G: List[List[int]], r: int, color: int) -> List[List[int]]:
        return dsl_paint_row(G, r, color)

    def dsl_paint_col(G: List[List[int]], c: int, color: int) -> List[List[int]]:
        return dsl_paint_col(G, c, color)

    def dsl_paint_cell(G: List[List[int]], r: int, c: int, color: int) -> List[List[int]]:
        return dsl_paint_cell(G, r, c, color)

    def dsl_mask_eq(G: List[List[int]], color: int) -> List[List[int]]:
        return dsl_mask_eq(G, color)

    def dsl_get_cell(G: List[List[int]], r: int, c: int) -> int:
        return dsl_get_cell(G, r, c)

    def dsl_set_cell(G: List[List[int]], r: int, c: int, val: int) -> List[List[int]]:
        return dsl_set_cell(G, r, c, val)

    top_row = dsl_get_cell(grid, 0, 0)
    if dsl_mask_eq(grid, 6):
        grid = dsl_paint_row(grid, 0, 6)
    else:
        grid = dsl_paint_row(grid, 0, top_row)

    for r in range(1, dsl_shape(grid)[0]):
        prev_row = dsl_get_cell(grid, r - 1, 0)
        curr_row = dsl_get_cell(grid, r, 0)
        if dsl_mask_eq(grid, 6) and dsl_mask_eq(grid, prev_row):
            grid = dsl_paint_row(grid, r, 6)
        elif dsl_mask_eq(grid, 6) and dsl_mask_eq(grid, curr_row):
            grid = dsl_paint_row(grid, r, 6)
        elif dsl_mask_eq(grid, prev_row) and dsl_mask_eq(grid, curr_row):
            grid = dsl_paint_row(grid, r, curr_row)
        elif dsl_mask_eq(grid, 6) and dsl_mask_eq(grid, curr_row):
            grid = dsl_paint_row(grid, r, 6)
        elif dsl_mask_eq(grid, prev_row) and dsl_mask_eq(grid, 6):
            grid = dsl_paint_row(grid, r, 6)
        else:
            grid = dsl_paint_row(grid, r, curr_row)

    return grid