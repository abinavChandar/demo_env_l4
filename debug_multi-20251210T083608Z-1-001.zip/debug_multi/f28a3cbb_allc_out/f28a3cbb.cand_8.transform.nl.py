from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    def repeat_row(grid: List[List[int]], r: int, val: int) -> List[List[int]]:
        return dsl_paint_row(grid, r, val)

    def repeat_top_row(grid: List[List[int]]) -> List[List[int]]:
        top_row = grid[0]
        val = top_row[0]
        for r in dsl_iter_coords(grid):
            if not dsl_mask_eq(grid, val):
                return repeat_row(grid, 0, val)
            if r > 0:
                grid = repeat_row(grid, r, val)
        return grid

    grid = grid
    while True:
        grid = repeat_top_row(grid)
        if dsl_bbox_of_mask(dsl_mask_eq(grid, grid[0][0])) is None:
            break
    return grid