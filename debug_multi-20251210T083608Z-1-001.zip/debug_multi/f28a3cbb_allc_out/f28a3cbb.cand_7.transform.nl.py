from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    def process_subgrid(G: List[List[int]]) -> List[List[int]]:
        top_left = dsl_get_cell(G, 0, 0)
        mask = dsl_mask_eq(G, top_left)
        G = dsl_paint_row(G, 0, top_left)
        G = dsl_paint_col(G, 0, top_left)
        G = dsl_paint_row(G, 1, top_left)
        G = dsl_paint_col(G, 1, top_left)
        G = dsl_paint_row(G, 2, top_left)
        G = dsl_paint_col(G, 2, top_left)
        G = dsl_paint_row(G, 3, top_left)
        G = dsl_paint_col(G, 3, top_left)
        G = dsl_paint_row(G, 4, top_left)
        G = dsl_paint_col(G, 4, top_left)
        G = dsl_paint_row(G, 5, top_left)
        G = dsl_paint_col(G, 5, top_left)
        G = dsl_paint_row(G, 6, top_left)
        G = dsl_paint_col(G, 6, top_left)
        G = dsl_paint_row(G, 7, top_left)
        G = dsl_paint_col(G, 7, top_left)
        G = dsl_paint_row(G, 8, top_left)
        G = dsl_paint_col(G, 8, top_left)
        G = dsl_paint_row(G, 9, top_left)
        G = dsl_paint_col(G, 9, top_left)
        G = dsl_paint_row(G, 10, top_left)
        G = dsl_paint_col(G, 10, top_left)
        G = dsl_paint_row(G, 11, top_left)
        G = dsl_paint_col(G, 11, top_left)
        G = dsl_paint_row(G, 12, top_left)
        G = dsl_paint_col(G, 12, top_left)
        G = dsl_paint_row(G, 13, top_left)
        G = dsl_paint_col(G, 13, top_left)
        G = dsl_paint_row(G, 14, top_left)
        G = dsl_paint_col(G, 14, top_left)
        G = dsl_paint_row(G, 15, top_left)
        G = dsl_paint_col(G, 15, top_left)
        return G

    G = dsl_zeros_like(grid, -1)
    for r in range(0, dsl_shape(grid)[0], 6):
        for c in range(0, dsl_shape(grid)[1], 6):
            subgrid = dsl_crop(grid, r, c, 6, 6)
            G = dsl_paste(G, process_subgrid(subgrid), r, c)
    for r in range(dsl_shape(grid)[0]):
        for c in range(dsl_shape(grid)[1]):
            if dsl_get_cell(G, r, c) != dsl_get_cell(grid, r, c):
                G = dsl_paint_cell(G, r, c, dsl_get_cell(G, r - 1, c))
    return G