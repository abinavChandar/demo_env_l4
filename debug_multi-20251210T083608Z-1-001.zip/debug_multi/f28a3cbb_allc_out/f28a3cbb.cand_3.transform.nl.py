from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    top_row = dsl_get_cell(grid, 0, 0)
    if top_row == 9:
        return dsl_paint_row(dsl_zeros_like(grid), 0, 9)
    elif top_row == 6:
        return dsl_paint_row(dsl_zeros_like(grid), 0, 6)
    elif top_row == 2:
        return dsl_paint_row(dsl_zeros_like(grid), 0, 2)
    elif top_row == 5:
        return dsl_paint_row(dsl_zeros_like(grid), 0, 5)
    else:
        first_9_row = next((r for r in dsl_iter_coords(grid) if dsl_get_cell(grid, r[0], 0) == 9), None)
        if first_9_row is not None:
            return dsl_paint_row(dsl_zeros_like(grid), first_9_row[0], dsl_get_cell(grid, first_9_row[0], 0))
        else:
            return dsl_paint_row(dsl_zeros_like(grid), 0, 6)