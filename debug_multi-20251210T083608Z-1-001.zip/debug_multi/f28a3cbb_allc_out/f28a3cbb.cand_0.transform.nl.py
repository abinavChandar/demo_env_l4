from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    rows, cols = dsl_shape(grid)
    target = dsl_get_cell(grid, *dsl_iter_coords(grid).next())
    new_target = target - 1
    mask = dsl_mask_eq(grid, target)
    grid = dsl_paint_row(grid, 0, new_target)
    grid = dsl_paint_row(grid, rows - 1, new_target)
    grid = dsl_paint_col(grid, 0, new_target)
    grid = dsl_paint_col(grid, cols - 1, new_target)
    if dsl_bbox_of_mask(mask) == dsl_bbox_of_mask(dsl_zeros_like(grid)):
        grid = dsl_paint_row(grid, rows // 2, new_target)
        grid = dsl_paint_col(grid, cols // 2, new_target)
    else:
        grid = dsl_flip_h(grid)
        grid = dsl_flip_v(grid)
        grid = dsl_paint_row(grid, rows // 2, new_target)
        grid = dsl_paint_col(grid, cols // 2, new_target)
    return grid