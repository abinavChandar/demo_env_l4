from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    top_row = dsl_paint_row(grid, 0, 9)
    second_row = dsl_paint_row(top_row, 1, 6)
    third_row = dsl_paint_row(second_row, 2, 4)
    return dsl_paint_masked(third_row, dsl_mask_eq(second_row, 4), 6)