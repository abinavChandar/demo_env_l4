from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    tl = dsl_get_cell(grid, 0, 0)
    br = dsl_get_cell(grid, dsl_shape(grid)[0] - 1, dsl_shape(grid)[1] - 1)
    if tl == br:
        return dsl_set_cell(dsl_clone(grid), dsl_shape(grid)[0] - 1, dsl_shape(grid)[1] - 1, tl)
    else:
        return dsl_set_cell(dsl_clone(grid), dsl_shape(grid)[0] - 1, dsl_shape(grid)[1] - 1, dsl_get_cell(grid, dsl_shape(grid)[0] - 1 - (dsl_shape(grid)[0] - 1), dsl_shape(grid)[1] - 1 - (dsl_shape(grid)[0] - 1)))