from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    def transform_row(row: List[int]) -> List[int]:
        return [row[0]] + [6] * (len(row) - 2) + [row[-1]]

    def transform_grid(grid: List[List[int]]) -> List[List[int]]:
        return [transform_row(row) for row in grid]

    grid = transform_grid(grid)
    grid = dsl_paint_col(grid, 0, 6)
    grid = dsl_paint_col(grid, -1, 6)
    return grid