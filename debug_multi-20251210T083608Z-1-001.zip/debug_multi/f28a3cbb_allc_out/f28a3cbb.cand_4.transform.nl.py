from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    for r in dsl_iter_coords(grid):
        top_row = dsl_get_cell(grid, 0, r[1])
        if dsl_get_cell(grid, r[0], r[1]) != top_row:
            dsl_set_cell(grid, r[0], r[1], top_row)
        if top_row == 6:
            dsl_set_cell(grid, r[0], r[1], 6)
        elif top_row == 9:
            dsl_set_cell(grid, r[0], r[1], 9)
        elif top_row == 2:
            dsl_set_cell(grid, r[0], r[1], 2)
        elif top_row == 5:
            dsl_set_cell(grid, r[0], r[1], 5)
        elif top_row == 4:
            dsl_set_cell(grid, r[0], r[1], 4)
        if top_row == 6:
            if dsl_get_cell(grid, r[0] + 1, r[1]) == 6:
                dsl_set_cell(grid, r[0] + 1, r[1], 6)
            elif dsl_get_cell(grid, r[0] + 1, r[1]) == 5:
                dsl_set_cell(grid, r[0] + 1, r[1], 5)
            elif dsl_get_cell(grid, r[0] + 1, r[1]) == 4:
                dsl_set_cell(grid, r[0] + 1, r[1], 4)
        elif top_row == 9:
            if dsl_get_cell(grid, r[0] + 1, r[1]) == 6:
                dsl_set_cell(grid, r[0] + 1, r[1], 6)
            elif dsl_get_cell(grid, r[0] + 1, r[1]) == 5:
                dsl_set_cell(grid, r[0] + 1, r[1], 5)
            elif dsl_get_cell(grid, r[0] + 1, r[1]) == 4:
                dsl_set_cell(grid, r[0] + 1, r[1], 4)
        elif top_row == 2:
            if dsl_get_cell(grid, r[0] + 1, r[1]) == 6:
                dsl_set_cell(grid, r[0] + 1, r[1], 6)
            elif dsl_get_cell(grid, r[0] + 1, r[1]) == 5:
                dsl_set_cell(grid, r[0] + 1, r[1], 5)
            elif dsl_get_cell(grid, r[0] + 1, r[1]) == 4:
                dsl_set_cell(grid, r[0] + 1, r[1], 4)
        elif top_row == 5:
            if dsl_get_cell(grid, r[0] + 1, r[1]) == 6:
                dsl_set_cell(grid, r[0] + 1, r[1], 6)
            elif dsl_get_cell(grid, r[0] + 1, r[1]) == 5:
                dsl_set_cell(grid, r[0] + 1, r[1], 5)
            elif dsl_get_cell(grid, r[0] + 1, r[1]) == 4:
                dsl_set_cell(grid, r[0] + 1, r[1], 4)
        elif top_row == 4:
            if dsl_get_cell(grid, r[0] + 1, r[1]) == 6:
                dsl_set_cell(grid, r[0] + 1, r[1], 6)
            elif dsl_get_cell(grid, r[0] + 1, r[1]) == 5:
                dsl_set_cell(grid, r[0] + 1, r[1], 5)