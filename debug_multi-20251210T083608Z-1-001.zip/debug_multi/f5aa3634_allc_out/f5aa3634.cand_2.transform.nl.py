from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    mid_row = next(r for r, _ in dsl_iter_coords(grid))
    mid_col = next(c for _, c in dsl_iter_coords(grid))
    sub_grid = dsl_crop(grid, mid_row - 1, mid_col - 1, 3, 3)
    output_grid = dsl_clone(grid)
    dsl_crop(output_grid, mid_row - 1, mid_col - 1, 3, 3)
    dsl_paste(output_grid, sub_grid, mid_row - 1, mid_col - 1)
    return output_grid