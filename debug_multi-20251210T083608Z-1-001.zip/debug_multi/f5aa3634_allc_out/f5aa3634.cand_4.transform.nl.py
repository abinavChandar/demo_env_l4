from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    mid_row = dsl_iter_coords(grid).filter(lambda x: x[0] == dsl_shape(grid)[0] // 2).next()[0]
    mid_col = dsl_iter_coords(grid).filter(lambda x: x[1] == dsl_shape(grid)[1] // 2).next()[1]
    sub_grid = dsl_crop(grid, mid_row - 1, mid_col - 1, 3, 3)
    output_grid = dsl_clone(grid)
    dsl_crop(output_grid, mid_row - 1, mid_col - 1, 3, 3)
    dsl_paste(output_grid, sub_grid, mid_row - 1, mid_col - 1)
    return output_grid