from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    top_left = dsl_crop(grid, 0, 0, 3, 3)
    unique_values = dsl_remap_colors(top_left, {val: i for i, val in enumerate(set(dsl_iter_coords(top_left)))})
    result = dsl_clone(grid)
    for r, c in dsl_iter_coords(top_left):
        dsl_set_cell(result, r, c, dsl_get_cell(unique_values, r, c))
    return result