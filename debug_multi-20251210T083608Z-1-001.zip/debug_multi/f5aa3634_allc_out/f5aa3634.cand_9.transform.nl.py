from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    middle_row = dsl_copy_row(grid, dsl_shape(grid)[0] // 2, 0)
    unique_values = set(dsl_iter_coords(middle_row))
    unique_values = [val for val in unique_values if val != 0]
    new_grid = dsl_zeros_like(grid)
    for i, val in enumerate(unique_values):
        r, c = divmod(i, dsl_shape(grid)[1])
        dsl_set_cell(new_grid, r, c, val)
    return new_grid