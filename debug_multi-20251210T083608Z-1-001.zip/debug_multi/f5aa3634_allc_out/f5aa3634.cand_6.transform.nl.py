from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    middle_row = dsl_copy_row(grid, dsl_shape(grid)[0] // 2, 0)
    non_zero_values = [dsl_get_cell(middle_row, c) for c in dsl_iter_coords(middle_row) if dsl_get_cell(middle_row, c) != 0]
    square_size = len(non_zero_values)
    square = dsl_full(square_size, square_size, 0)
    for i, val in enumerate(non_zero_values):
        dsl_set_cell(square, i, i, val)
    return square