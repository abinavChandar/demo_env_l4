from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    middle_row = dsl_iter_coords(grid).filter(lambda x: x[0] == dsl_shape(grid)[0] // 2).map(lambda x: x[1]).first()
    top_left_3x3 = dsl_crop(grid, middle_row - 1, middle_row - 1, 3, 3)
    return dsl_copy_col(top_left_3x3, 0, 0)