from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    top_left_3x3 = dsl_crop(grid, 0, 0, 3, 3)
    return top_left_3x3