from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    middle_row = dsl_copy_row(grid, dsl_shape(grid)[0] // 2, 0)
    non_zero_values = dsl_mask_eq(middle_row, 0)
    mask = dsl_not(non_zero_values)
    values = dsl_paint_row(middle_row, 0, 255)
    new_grid = dsl_zeros_like(grid, 0)
    dsl_paint_row(new_grid, 0, values)
    dsl_paint_row(new_grid, 1, values)
    dsl_paint_row(new_grid, 2, values)
    dsl_paint_col(new_grid, 0, values)
    dsl_paint_col(new_grid, 1, values)
    dsl_paint_col(new_grid, 2, values)
    return new_grid