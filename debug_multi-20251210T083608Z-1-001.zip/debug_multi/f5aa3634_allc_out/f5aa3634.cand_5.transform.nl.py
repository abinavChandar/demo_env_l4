from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    sub_grid = dsl_crop(grid, 0, 0, 3, 3)
    output = dsl_zeros_like(grid, 8)
    dsl_paste(output, sub_grid, 1, 1)
    return output