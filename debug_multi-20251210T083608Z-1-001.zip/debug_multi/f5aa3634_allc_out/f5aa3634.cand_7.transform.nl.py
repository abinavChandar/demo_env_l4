from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    middle_row = dsl_copy_row(grid, dsl_shape(grid)[0] // 2, 0)
    third_col = dsl_copy_col(middle_row, 2)
    return dsl_full(3, 3, third_col[0])