from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    output = dsl_clone(grid)
    for r in dsl_iter_coords(grid):
        middle_row = dsl_mask_eq(grid, dsl_get_cell(grid, r[0], dsl_shape(grid)[1] // 2))
        if dsl_bbox_of_mask(middle_row):
            middle_row = dsl_zeros_like(middle_row)
            above_row = dsl_zeros_like(dsl_component_mask(grid, r[0], dsl_shape(grid)[1] // 2 - 1))
            below_row = dsl_zeros_like(dsl_component_mask(grid, r[0], dsl_shape(grid)[1] // 2 + 1))
            middle_row = dsl_paint_row(middle_row, r[0], dsl_get_cell(output, r[0], dsl_shape(grid)[1] // 2))
            middle_row = dsl_paint_col(middle_row, dsl_shape(grid)[1] // 2, dsl_get_cell(output, r[0], dsl_shape(grid)[1] // 2 - 2))
            middle_row = dsl_paint_col(middle_row, dsl_shape(grid)[1] // 2, dsl_get_cell(output, r[0], dsl_shape(grid)[1] // 2 + 2))
            for c in dsl_iter_coords(grid):
                if dsl_bbox_of_mask(middle_row) and dsl_bbox_of_mask(above_row) and dsl_bbox_of_mask(below_row):
                    if c[1] == dsl_shape(grid)[1] // 2:
                        middle_row = dsl_paint_col(middle_row, c[1], dsl_get_cell(output, r[0], c[1]))
                    elif c[1] < dsl_shape(grid)[1] // 2:
                        middle_row = dsl_paint_col(middle_row, c[1], dsl_get_cell(output, r[0], c[1] - 2))
                    else:
                        middle_row = dsl_paint_col(middle_row, c[1], dsl_get_cell(output, r[0], c[1] + 2))
            grid = dsl_paint_row(grid, r[0], dsl_get_cell(middle_row, r[0], dsl_shape(grid)[1] // 2))
            grid = dsl_paint_row(grid, r[0], dsl_get_cell(above_row, r[0], dsl_shape(grid)[1] // 2 - 1))
            grid = dsl_paint_row(grid, r[0], dsl_get_cell(below_row, r[0], dsl_shape(grid)[1] // 2 + 1))
            grid = dsl_paint_row(grid, r[0], dsl_get_cell(middle_row, r[0], dsl_shape(grid)[1] // 2))
    return grid