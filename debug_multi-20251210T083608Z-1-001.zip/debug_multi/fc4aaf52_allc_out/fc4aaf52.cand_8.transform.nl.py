from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    def transform_row(row: List[int]) -> List[int]:
        center = dsl_get_cell(row, dsl_shape(row)[0] // 2)
        if center == 0:
            return dsl_paint_row(dsl_clone(row), dsl_shape(row)[0] // 2, 5)
        elif center == 1:
            return dsl_paint_row(dsl_clone(row), dsl_shape(row)[0] // 2, 2)
        elif center == 2:
            return dsl_paint_row(dsl_clone(row), dsl_shape(row)[0] // 2, 1)
        elif center == 5:
            return dsl_paint_row(dsl_clone(row), dsl_shape(row)[0] // 2, 0)
        else:
            return dsl_paint_row(dsl_clone(row), dsl_shape(row)[0] // 2, center)

    return dsl_iter(dsl_iter_coords(grid), lambda r, c: dsl_set_cell(transform_row(dsl_get_row(grid, r)), r, c))