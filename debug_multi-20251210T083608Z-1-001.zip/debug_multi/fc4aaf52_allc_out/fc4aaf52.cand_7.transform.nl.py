from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    center_row = dsl_iter_coords(grid).filter(lambda x: dsl_get_cell(grid, x[0], x[1]) == dsl_shape(grid)[1] // 2).next()[0]
    mask = dsl_mask_eq(grid, dsl_get_cell(grid, center_row, dsl_shape(grid)[1] // 2))
    grid = dsl_paint_row(grid, center_row, dsl_clamp(255 - dsl_get_cell(grid, center_row, dsl_shape(grid)[1] // 2)))
    grid = dsl_paint_row(grid, center_row - 1, dsl_clamp(255 - dsl_get_cell(grid, center_row - 1, dsl_shape(grid)[1] // 2)))
    grid = dsl_paint_row(grid, center_row + 1, dsl_clamp(255 - dsl_get_cell(grid, center_row + 1, dsl_shape(grid)[1] // 2)))
    while True:
        new_mask = dsl_mask_eq(grid, dsl_clamp(255 - dsl_get_cell(grid, center_row - 1, dsl_shape(grid)[1] // 2)))
        if not dsl_iter_coords(new_mask).any():
            break
        center_row -= 1
        mask = new_mask
        grid = dsl_paint_row(grid, center_row, dsl_clamp(255 - dsl_get_cell(grid, center_row, dsl_shape(grid)[1] // 2)))
        grid = dsl_paint_row(grid, center_row - 1, dsl_clamp(255 - dsl_get_cell(grid, center_row - 1, dsl_shape(grid)[1] // 2)))
    while True:
        new_mask = dsl_mask_eq(grid, dsl_clamp(255 - dsl_get_cell(grid, center_row + 1, dsl_shape(grid)[1] // 2)))
        if not dsl_iter_coords(new_mask).any():
            break
        center_row += 1
        mask = new_mask
        grid = dsl_paint_row(grid, center_row, dsl_clamp(255 - dsl_get_cell(grid, center_row, dsl_shape(grid)[1] // 2)))
        grid = dsl_paint_row(grid, center_row + 1, dsl_clamp(255 - dsl_get_cell(grid, center_row + 1, dsl_shape(grid)[1] // 2)))
    return grid