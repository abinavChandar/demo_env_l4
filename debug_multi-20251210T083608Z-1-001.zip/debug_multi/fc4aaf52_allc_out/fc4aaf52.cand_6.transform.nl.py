from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    for _ in range(40):
        center_col = dsl_paint_col(grid, dsl_shape(grid)[1] // 2, 0)
        second_row = dsl_paint_row(grid, 1, 0)
        grid = dsl_paint_row(grid, 1, dsl_get_cell(center_col, 0))
        grid = dsl_paint_col(grid, dsl_shape(grid)[1] // 2, dsl_get_cell(second_row, 0))
    return grid