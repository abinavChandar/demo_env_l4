from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    target_row = dsl_iter_coords(grid).map(lambda x: x[0]).median()
    for r in dsl_iter_coords(grid):
        if r[0] == target_row:
            new_row = dsl_zeros_like(grid)
            new_row[0] = dsl_get_cell(grid, r[0], r[1])
            grid = dsl_paint_row(grid, r[0], new_row)
            grid = dsl_paint_row(grid, r[0] - 1, dsl_get_cell(grid, r[0] - 1, r[1]))
        else:
            grid = dsl_paint_row(grid, r[0], dsl_zeros_like(grid))
    return grid