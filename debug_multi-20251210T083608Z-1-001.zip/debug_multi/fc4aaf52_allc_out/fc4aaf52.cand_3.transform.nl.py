from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    def process_row(row: List[int]) -> List[int]:
        center = len(row) // 2
        if dsl_mask_eq(row, 8)[center]:
            return dsl_paint_row(dsl_zeros_like(grid, 8), center, 8)
        elif dsl_mask_eq(row, 0)[center]:
            if sum(1 for x in row if x == 0) == 1:
                return dsl_paint_row(dsl_zeros_like(grid, 8), center, 5)
            elif sum(1 for x in row if x == 0) == 2:
                return dsl_paint_row(dsl_zeros_like(grid, 8), center, [0, 5])
            elif sum(1 for x in row if x == 0) == 3:
                return dsl_paint_row(dsl_zeros_like(grid, 8), center, [0, 5, 0])
        elif dsl_mask_eq(row, 1)[center]:
            if sum(1 for x in row if x == 1) == 1:
                return dsl_paint_row(dsl_zeros_like(grid, 8), center, 2)
            elif sum(1 for x in row if x == 1) == 2:
                return dsl_paint_row(dsl_zeros_like(grid, 8), center, [1, 2])
            elif sum(1 for x in row if x == 1) == 3:
                return dsl_paint_row(dsl_zeros_like(grid, 8), center, [1, 2, 1])
        elif dsl_mask_eq(row, 5)[center]:
            if sum(1 for x in row if x == 5) == 1:
                return dsl_paint_row(dsl_zeros_like(grid, 8), center, 0)
            elif sum(1 for x in row if x == 5) == 2:
                return dsl_paint_row(dsl_zeros_like(grid, 8), center, [0, 5])
            elif sum(1 for x in row if x == 5) == 3:
                return dsl_paint_row(dsl_zeros_like(grid, 8), center, [0, 5, 0])
        else:
            return dsl_paint_row(dsl_zeros_like(grid, 8), center, dsl_get_cell(grid, center, center))
    return [process_row(row) for row in grid]