from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    output = dsl_clone(grid)
    middle_row, middle_col = dsl_iter_coords(output)
    dsl_set_cell(output, middle_row, middle_col, dsl_get_cell(grid, middle_row, middle_col))
    while True:
        updated = False
        for r, c in dsl_iter_coords(output):
            if dsl_in_bounds(grid, r, c) and dsl_in_bounds(output, r, c):
                if dsl_get_cell(output, r, c) == 0:
                    updated = True
                    dsl_set_cell(output, r, c, dsl_get_cell(grid, r, c))
        if not updated:
            break
    return output