from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    top_row = dsl_mask_eq(dsl_clone(grid), 2)
    bottom_row = dsl_mask_eq(dsl_clone(grid), 2)
    top_row_coords = dsl_iter_coords(top_row)
    bottom_row_coords = dsl_iter_coords(bottom_row)
    top_row_coords = [coord for coord in top_row_coords if dsl_get_cell(grid, coord[0], coord[1]) == 2]
    bottom_row_coords = [coord for coord in bottom_row_coords if dsl_get_cell(grid, coord[0], coord[1]) == 2]
    top_row = dsl_mask_eq(dsl_clone(grid), 2)
    bottom_row = dsl_mask_eq(dsl_clone(grid), 2)
    top_row = dsl_paint_row(top_row, top_row_coords[0][0], 1)
    bottom_row = dsl_paint_row(bottom_row, bottom_row_coords[0][0], 1)
    middle_rows = dsl_mask_eq(dsl_clone(grid), 0)
    output_grid = dsl_zeros_like(grid)
    for row in dsl_iter_coords(grid):
        if row[0] == top_row_coords[0][0] or row[0] == bottom_row_coords[0][0]:
            output_grid = dsl_paint_row(output_grid, row[0], 1)
        else:
            output_grid = dsl_paint_row(output_grid, row[0], 0)
    return output_grid