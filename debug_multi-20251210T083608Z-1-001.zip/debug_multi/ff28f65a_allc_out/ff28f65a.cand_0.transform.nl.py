from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    top_row = dsl_mask_eq(dsl_clone(grid), 1)
    bottom_row = dsl_mask_eq(dsl_clone(grid), 1)
    bottom_row = dsl_flip_v(bottom_row)
    non_zero_coords = dsl_iter_coords(dsl_and(top_row, bottom_row))
    non_zero_coords = [coord for coord in non_zero_coords if dsl_get_cell(grid, coord[0], coord[1]) != 0]
    new_grid = dsl_full(3, 3, 0)
    for i in range(3):
        for j in range(3):
            if i < len(non_zero_coords) and j < len(non_zero_coords[i]):
                dsl_set_cell(new_grid, i, j, 1)
            else:
                dsl_set_cell(new_grid, i, j, 0)
    return new_grid