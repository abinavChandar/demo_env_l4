from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    top_row = dsl_mask_eq(grid, 1)[0]
    bottom_row = dsl_mask_eq(grid, 1)[-1]
    new_grid = dsl_zeros_like(grid)
    new_grid = dsl_paint_row(new_grid, 0, [1, 0, 1])
    new_grid = dsl_paint_row(new_grid, len(top_row), [1, 0, 1])
    for r in range(1, len(top_row) - 1):
        new_grid = dsl_paint_row(new_grid, r, [0] * 3)
    return new_grid