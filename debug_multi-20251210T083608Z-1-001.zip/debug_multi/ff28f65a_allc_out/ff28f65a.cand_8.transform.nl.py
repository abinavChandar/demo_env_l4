from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    top_row = dsl_mask_eq(dsl_clone(grid), 2)[0]
    bottom_row = dsl_mask_eq(dsl_clone(grid), 2)[-1]
    if dsl_get_cell(top_row, 0):
        mid_col = dsl_mask_eq(dsl_clone(grid), 2)[0][dsl_shape(dsl_mask_eq(dsl_clone(grid), 2))[1] // 2]
    else:
        mid_col = dsl_mask_eq(dsl_clone(grid), 2)[-1][dsl_shape(dsl_mask_eq(dsl_clone(grid), 2))[1] // 2]
    new_grid = dsl_zeros_like(grid, 1)
    dsl_paint_col(new_grid, 0, 1)
    dsl_paint_col(new_grid, dsl_shape(new_grid)[1] - 1, 1)
    if dsl_get_cell(mid_col, 0):
        dsl_paint_col(new_grid, dsl_shape(new_grid)[1] // 2, 0)
    else:
        dsl_paint_col(new_grid, dsl_shape(new_grid)[1] // 2, 1)
    return new_grid