from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    top_row = dsl_mask_eq(dsl_copy_row(grid, 0, 0), 0)
    bottom_row = dsl_mask_eq(dsl_copy_row(grid, dsl_shape(grid)[0] - 1, 0), 0)
    mask = dsl_mask_eq(dsl_mask_or(top_row, bottom_row), 0)
    new_grid = dsl_zeros_like(grid)
    dsl_paint_col(new_grid, dsl_shape(grid)[1] // 2, 1)
    for r, c in dsl_iter_coords(grid):
        if not dsl_mask_eq(mask, r, c):
            dsl_paint_col(new_grid, c, 1)
    new_grid = dsl_filter_rows(new_grid, lambda row: not dsl_mask_eq(row, 0))
    return new_grid