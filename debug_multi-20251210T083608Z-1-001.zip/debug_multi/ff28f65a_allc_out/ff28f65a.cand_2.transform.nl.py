from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    top_row = next((r for r in grid if sum(r) == 1), None)
    bottom_row = next((r for r in reversed(grid) if sum(r) == 1), None)
    new_grid = dsl_full(dsl_shape(grid)[0], dsl_shape(grid)[1], 0)
    dsl_paint_cell(new_grid, 0, 0, 1)
    dsl_paint_cell(new_grid, dsl_shape(new_grid)[0] - 1, dsl_shape(new_grid)[1] - 1, 1)
    for r, row in enumerate(grid):
        if sum(row) > 0:
            dsl_paint_cell(new_grid, r, dsl_shape(new_grid)[1] - 1, 0)
            leftmost = next((c for c, val in enumerate(row) if val != 0), None)
            if leftmost is not None:
                dsl_paint_cell(new_grid, r, leftmost, 1)
            rightmost = next((c for c, val in enumerate(reversed(row)) if val != 0), None)
            if rightmost is not None:
                dsl_paint_cell(new_grid, r, dsl_shape(new_grid)[1] - 1 - rightmost, 0)
            mid = (leftmost + rightmost) // 2
            dsl_paint_cell(new_grid, r, mid, 0)
    return new_grid