from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    non_zero_values = dsl_iter_coords(dsl_mask_eq(grid, 0))
    topmost = max(r for r, c in non_zero_values)
    leftmost = min(c for r, c in non_zero_values)
    new_grid = dsl_zeros_like(grid)
    for r, c in non_zero_values:
        distance_from_top = r - topmost
        distance_from_left = c - leftmost
        new_grid = dsl_paint_row(new_grid, distance_from_top, 1)
        new_grid = dsl_paint_col(new_grid, distance_from_left, 1)
        new_grid = dsl_paint_cell(new_grid, distance_from_top, distance_from_left, 1)
    return new_grid