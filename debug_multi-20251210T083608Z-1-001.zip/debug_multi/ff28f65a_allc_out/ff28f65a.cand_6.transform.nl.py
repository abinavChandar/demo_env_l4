from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    top_row = dsl_mask_eq(dsl_copy_row(grid, 0, 0), 2)
    bottom_row = dsl_mask_eq(dsl_copy_row(grid, len(grid) - 1, 0), 2)
    new_grid = dsl_zeros_like(grid, 0)
    for r in dsl_iter_coords(new_grid):
        for c in dsl_iter_coords(new_grid):
            if dsl_in_bounds(top_row, r, c) and dsl_in_bounds(bottom_row, r, c):
                if dsl_get_cell(top_row, r, c) and dsl_get_cell(bottom_row, r, c):
                    if r == 0:
                        dsl_set_cell(new_grid, r, c, 1)
                    else:
                        dsl_set_cell(new_grid, r, c, 0)
    return new_grid