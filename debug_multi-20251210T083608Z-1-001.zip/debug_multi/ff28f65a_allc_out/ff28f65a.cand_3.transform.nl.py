from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    top_row = dsl_mask_eq(dsl_get_cell(grid, 0, 0), 0)
    bottom_row = dsl_mask_eq(dsl_get_cell(grid, dsl_shape(grid)[0] - 1, 0), 0)
    mask = dsl_not(dsl_or(top_row, bottom_row))
    new_grid = dsl_zeros_like(grid)
    for r, c in dsl_iter_coords(grid):
        if dsl_get_cell(top_row, c):
            dsl_set_cell(new_grid, r, c, 1)
        elif dsl_get_cell(bottom_row, c):
            dsl_set_cell(new_grid, r, c, 0)
    return new_grid