from dsl_primitives import *

def transform(grid: List[List[int]]) -> List[List[int]]:
    mask = dsl_mask_eq(grid, 0)
    mask = dsl_not(mask)
    top_row = dsl_bbox_of_mask(mask)
    if top_row is None:
        return dsl_zeros_like(grid)
    top_row = top_row[0]
    bottom_row = dsl_bbox_of_mask(dsl_not(mask))
    if bottom_row is None:
        return dsl_zeros_like(grid)
    bottom_row = bottom_row[1]
    new_grid = dsl_full(grid[bottom_row][0], grid[0].__len__(), 0)
    for r in dsl_iter_coords(grid):
        if r[0] >= top_row and r[0] <= bottom_row:
            new_grid = dsl_paint_col(new_grid, r[1], 1)
            if dsl_get_cell(grid, r[0], r[1]) != 0:
                new_grid = dsl_paint_col(new_grid, r[1], 0)
    return new_grid